import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import type { Job, UserProfile } from "@shared/schema";
import UserInteractionPanel from "./user-interaction-panel";

export default function RightSidebar() {
  const { data: jobs = [] } = useQuery<Job[]>({
    queryKey: ["/api/jobs"],
  });

  const { data: suggestedUsers = [] } = useQuery<UserProfile[]>({
    queryKey: ["/api/suggestions/users"],
  });

  return (
    <aside className="space-y-6">
      {/* Job Recommendations */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-semibold text-gray-900">Recommended Jobs</h4>
            <a href="#" className="connexta-blue text-sm hover:underline">
              View all
            </a>
          </div>
          
          <div className="space-y-4">
            {jobs.slice(0, 3).map((job) => (
              <div key={job.id} className="border-b border-gray-100 pb-4 last:border-b-0 last:pb-0">
                <h5 className="font-medium text-gray-900 text-sm">{job.title}</h5>
                <p className="text-sm text-gray-600">{job.company}</p>
                <p className="text-xs text-gray-500 mt-1">
                  {job.location} {job.salary && `• ${job.salary}`}
                </p>
                {job.recruiterName && (
                  <div className="flex items-center mt-2">
                    <img
                      src={job.recruiterPicture || "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=20&h=20"}
                      alt={job.recruiterName}
                      className="w-5 h-5 rounded-full mr-2 object-cover"
                    />
                    <span className="text-xs text-gray-500">Actively recruiting</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* People You May Know */}
      <UserInteractionPanel users={suggestedUsers} />

      {/* Trending Topics */}
      <Card>
        <CardContent className="p-4">
          <h4 className="font-semibold text-gray-900 mb-4">Trending in Tech</h4>
          <div className="space-y-3">
            <div className="border-b border-gray-100 pb-3 last:border-b-0 last:pb-0">
              <h5 className="text-sm font-medium text-gray-900">#AIRevolution</h5>
              <p className="text-xs text-gray-500">15,240 professionals talking about this</p>
            </div>
            <div className="border-b border-gray-100 pb-3 last:border-b-0 last:pb-0">
              <h5 className="text-sm font-medium text-gray-900">#RemoteWork</h5>
              <p className="text-xs text-gray-500">8,932 professionals talking about this</p>
            </div>
            <div>
              <h5 className="text-sm font-medium text-gray-900">#TechCareers</h5>
              <p className="text-xs text-gray-500">6,547 professionals talking about this</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </aside>
  );
}
