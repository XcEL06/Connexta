import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { apiRequest } from "@/lib/queryClient";
import { Users, UserCheck } from "lucide-react";

interface FollowStatsProps {
  userId: number;
  showCards?: boolean;
}

export default function FollowStats({ userId, showCards = true }: FollowStatsProps) {
  const { data: stats } = useQuery({
    queryKey: ["/api/follow/stats", userId],
    queryFn: async () => {
      const response = await apiRequest("GET", `/api/follow/stats/${userId}`, undefined);
      return response.json();
    },
  });

  const { data: followers = [] } = useQuery({
    queryKey: ["/api/followers", userId],
    queryFn: async () => {
      const response = await apiRequest("GET", `/api/followers/${userId}`, undefined);
      return response.json();
    },
  });

  const { data: following = [] } = useQuery({
    queryKey: ["/api/following", userId],
    queryFn: async () => {
      const response = await apiRequest("GET", `/api/following/${userId}`, undefined);
      return response.json();
    },
  });

  if (!showCards) {
    return (
      <div className="flex space-x-6 text-sm">
        <div className="flex items-center space-x-1">
          <Users className="w-4 h-4 text-gray-500" />
          <span className="font-medium">{stats?.followers || 0}</span>
          <span className="text-gray-500">followers</span>
        </div>
        <div className="flex items-center space-x-1">
          <UserCheck className="w-4 h-4 text-gray-500" />
          <span className="font-medium">{stats?.following || 0}</span>
          <span className="text-gray-500">following</span>
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-4">
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center space-x-3">
            <Users className="w-8 h-8 connexta-blue" />
            <div>
              <p className="text-2xl font-bold">{stats?.followers || 0}</p>
              <p className="text-sm text-gray-600">Followers</p>
            </div>
          </div>
          {followers.length > 0 && (
            <div className="mt-3">
              <div className="flex -space-x-2">
                {followers.slice(0, 3).map((follower: any) => (
                  <img
                    key={follower.id}
                    src={follower.profilePicture || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=30&h=30"}
                    alt={`${follower.firstName} ${follower.lastName}`}
                    className="w-6 h-6 rounded-full border-2 border-white object-cover"
                  />
                ))}
                {followers.length > 3 && (
                  <div className="w-6 h-6 rounded-full bg-gray-200 border-2 border-white flex items-center justify-center text-xs text-gray-600">
                    +{followers.length - 3}
                  </div>
                )}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <div className="flex items-center space-x-3">
            <UserCheck className="w-8 h-8 connexta-blue" />
            <div>
              <p className="text-2xl font-bold">{stats?.following || 0}</p>
              <p className="text-sm text-gray-600">Following</p>
            </div>
          </div>
          {following.length > 0 && (
            <div className="mt-3">
              <div className="flex -space-x-2">
                {following.slice(0, 3).map((user: any) => (
                  <img
                    key={user.id}
                    src={user.profilePicture || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=30&h=30"}
                    alt={`${user.firstName} ${user.lastName}`}
                    className="w-6 h-6 rounded-full border-2 border-white object-cover"
                  />
                ))}
                {following.length > 3 && (
                  <div className="w-6 h-6 rounded-full bg-gray-200 border-2 border-white flex items-center justify-center text-xs text-gray-600">
                    +{following.length - 3}
                  </div>
                )}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}