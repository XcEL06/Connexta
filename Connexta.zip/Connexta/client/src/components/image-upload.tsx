import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Camera, Upload, X } from "lucide-react";

interface ImageUploadProps {
  type: "profile" | "cover" | "post";
  onUploadComplete?: (imageUrl: string) => void;
  currentImageUrl?: string;
  className?: string;
  children?: React.ReactNode;
}

export default function ImageUpload({ 
  type, 
  onUploadComplete, 
  currentImageUrl, 
  className = "",
  children 
}: ImageUploadProps) {
  const [isUploading, setIsUploading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Invalid file type",
        description: "Please select an image file",
        variant: "destructive",
      });
      return;
    }

    // Validate file size (5MB for posts/covers, 3MB for profiles)
    const maxSize = type === 'profile' ? 3 * 1024 * 1024 : 5 * 1024 * 1024;
    if (file.size > maxSize) {
      toast({
        title: "File too large",
        description: `File size must be less than ${maxSize / (1024 * 1024)}MB`,
        variant: "destructive",
      });
      return;
    }

    // Create preview
    const reader = new FileReader();
    reader.onload = (e) => {
      setPreviewUrl(e.target?.result as string);
    };
    reader.readAsDataURL(file);

    // Upload file
    uploadFile(file);
  };

  const uploadFile = async (file: File) => {
    setIsUploading(true);
    
    try {
      const formData = new FormData();
      formData.append(type === 'profile' ? 'profile' : type === 'cover' ? 'cover' : 'image', file);

      const endpoint = `/api/upload/${type}`;
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Upload failed');
      }

      const data = await response.json();
      
      toast({
        title: "Upload successful",
        description: data.message,
      });

      if (onUploadComplete) {
        onUploadComplete(data.imageUrl);
      }

      setPreviewUrl(null);
    } catch (error) {
      console.error('Upload error:', error);
      toast({
        title: "Upload failed",
        description: "Failed to upload image. Please try again.",
        variant: "destructive",
      });
      setPreviewUrl(null);
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const triggerFileSelect = () => {
    fileInputRef.current?.click();
  };

  const clearPreview = () => {
    setPreviewUrl(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className={`relative ${className}`}>
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileSelect}
        className="hidden"
      />

      {children ? (
        <div onClick={triggerFileSelect} className="cursor-pointer">
          {children}
        </div>
      ) : (
        <Button
          onClick={triggerFileSelect}
          disabled={isUploading}
          variant="outline"
          className="flex items-center space-x-2"
        >
          {isUploading ? (
            <>
              <Upload className="w-4 h-4 animate-spin" />
              <span>Uploading...</span>
            </>
          ) : (
            <>
              <Camera className="w-4 h-4" />
              <span>
                {type === 'profile' ? 'Upload Profile Photo' : 
                 type === 'cover' ? 'Upload Cover Photo' : 
                 'Upload Image'}
              </span>
            </>
          )}
        </Button>
      )}

      {/* Preview Modal */}
      {previewUrl && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">Preview</h3>
              <Button variant="ghost" size="sm" onClick={clearPreview}>
                <X className="w-4 h-4" />
              </Button>
            </div>
            <div className="mb-4">
              <img 
                src={previewUrl} 
                alt="Preview" 
                className={`w-full rounded-lg ${
                  type === 'profile' ? 'aspect-square object-cover' :
                  type === 'cover' ? 'aspect-[3/1] object-cover' :
                  'max-h-64 object-contain'
                }`}
              />
            </div>
            <div className="flex space-x-2">
              <Button 
                onClick={clearPreview}
                variant="outline"
                className="flex-1"
              >
                Cancel
              </Button>
              <Button 
                onClick={() => {
                  const file = fileInputRef.current?.files?.[0];
                  if (file) uploadFile(file);
                }}
                disabled={isUploading}
                className="flex-1"
              >
                {isUploading ? 'Uploading...' : 'Upload'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}