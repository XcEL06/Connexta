import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { authService } from "@/lib/auth";

interface AddFriendButtonProps {
  targetUserId: number;
  className?: string;
}

const AddFriendButton = ({ targetUserId, className = "btn-add-friend" }: AddFriendButtonProps) => {
  const [status, setStatus] = useState("Add Friend");
  const { toast } = useToast();
  const currentUserId = authService.getState().user?.id;

  const handleAddFriend = async () => {
    if (!currentUserId) {
      toast({
        title: "Error",
        description: "You must be logged in to send friend requests",
        variant: "destructive",
      });
      return;
    }

    try {
      await apiRequest("POST", "/api/friends/addfriend", { 
        requesterId: currentUserId, 
        recipientId: targetUserId 
      });
      setStatus("Request Sent");
      toast({
        title: "Friend request sent!",
        description: "Your friend request has been sent successfully.",
      });
    } catch (error) {
      console.error("Error adding friend", error);
      toast({
        title: "Error",
        description: "Failed to send friend request. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <button onClick={handleAddFriend} className={className}>
      {status}
    </button>
  );
};

export default AddFriendButton;