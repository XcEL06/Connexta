import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { authService } from "@/lib/auth";
import { Image, Send, X } from "lucide-react";
import ImageUpload from "./image-upload";

export default function PostComposer() {
  const [content, setContent] = useState("");
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const { toast } = useToast();
  const user = authService.getState().user;

  const createPostMutation = useMutation({
    mutationFn: async () => {
      const postData = {
        content: content.trim(),
        ...(imageUrl && { imageUrl })
      };
      
      const response = await apiRequest("POST", "/api/posts", postData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      setContent("");
      setImageUrl(null);
      toast({
        title: "Post created!",
        description: "Your post has been shared successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: "Failed to create post. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = () => {
    if (!content.trim() && !imageUrl) {
      toast({
        title: "Empty post",
        description: "Please add some content or an image to your post.",
        variant: "destructive",
      });
      return;
    }

    createPostMutation.mutate();
  };

  const removeImage = () => {
    setImageUrl(null);
  };

  if (!user) return null;

  return (
    <Card className="mb-6">
      <CardContent className="p-4">
        <div className="flex space-x-3">
          <img
            src={user.profilePicture || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40"}
            alt={`${user.firstName} ${user.lastName}`}
            className="w-10 h-10 rounded-full object-cover"
          />
          <div className="flex-1">
            <Textarea
              placeholder="What's on your mind?"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="min-h-[100px] resize-none border-none shadow-none focus:ring-0 p-0 text-base"
              style={{ boxShadow: 'none' }}
            />
            
            {imageUrl && (
              <div className="mt-3 relative">
                <img
                  src={imageUrl}
                  alt="Post image"
                  className="max-w-full max-h-64 rounded-lg object-cover"
                />
                <Button
                  onClick={removeImage}
                  variant="destructive"
                  size="sm"
                  className="absolute top-2 right-2 h-8 w-8 p-0"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            )}

            <div className="flex items-center justify-between mt-4 pt-3 border-t border-gray-100">
              <div className="flex space-x-2">
                <ImageUpload
                  type="post"
                  onUploadComplete={(url) => setImageUrl(url)}
                >
                  <Button variant="ghost" size="sm" className="text-gray-600 hover:text-gray-800">
                    <Image className="w-4 h-4 mr-2" />
                    Photo
                  </Button>
                </ImageUpload>
              </div>

              <Button
                onClick={handleSubmit}
                disabled={createPostMutation.isPending || (!content.trim() && !imageUrl)}
                className="bg-connexta-blue hover:bg-connexta-navy text-white"
              >
                {createPostMutation.isPending ? (
                  "Posting..."
                ) : (
                  <>
                    <Send className="w-4 h-4 mr-2" />
                    Post
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}