import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { authService } from "@/lib/auth";

interface FollowButtonProps {
  currentUserId?: number;
  targetUserId: number;
  className?: string;
}

const FollowButton = ({ currentUserId, targetUserId, className = "btn-follow" }: FollowButtonProps) => {
  const [isFollowing, setIsFollowing] = useState(false);
  const { toast } = useToast();
  const actualCurrentUserId = currentUserId || authService.getState().user?.id;

  useEffect(() => {
    if (!actualCurrentUserId) return;
    
    // Check if the currentUserId is following the targetUserId
    const checkFollowStatus = async () => {
      try {
        const response = await apiRequest("GET", `/api/follow/check?followerId=${actualCurrentUserId}&followingId=${targetUserId}`, undefined);
        const data = await response.json();
        setIsFollowing(data.isFollowing);
      } catch (error) {
        console.error("Error checking follow status", error);
      }
    };

    checkFollowStatus();
  }, [actualCurrentUserId, targetUserId]);

  const handleFollow = async () => {
    if (!actualCurrentUserId) {
      toast({
        title: "Error",
        description: "You must be logged in to follow users",
        variant: "destructive",
      });
      return;
    }

    if (isFollowing) {
      // Unfollow
      try {
        await apiRequest("POST", "/api/follow/unfollow", { 
          followerId: actualCurrentUserId, 
          followingId: targetUserId 
        });
        setIsFollowing(false);
        toast({
          title: "Unfollowed successfully!",
          description: "You are no longer following this user.",
        });
      } catch (error) {
        console.error("Error unfollowing user", error);
        toast({
          title: "Error",
          description: "Error unfollowing user",
          variant: "destructive",
        });
      }
    } else {
      // Follow
      try {
        await apiRequest("POST", "/api/follow/follow", { 
          followerId: actualCurrentUserId, 
          followingId: targetUserId 
        });
        setIsFollowing(true);
        toast({
          title: "Followed successfully!",
          description: "You are now following this user.",
        });
      } catch (error) {
        console.error("Error following user", error);
        toast({
          title: "Error",
          description: "Error following user",
          variant: "destructive",
        });
      }
    }
  };

  return (
    <button onClick={handleFollow} className={className}>
      {isFollowing ? "Unfollow" : "Follow"}
    </button>
  );
};

export default FollowButton;