import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { authService } from "@/lib/auth";
import { UserPlus, Check, X } from "lucide-react";

interface FriendActionsProps {
  recipientId: number;
  requesterId?: number;
  variant?: "add" | "accept" | "reject";
  size?: "sm" | "default";
}

export default function FriendActions({ 
  recipientId, 
  requesterId, 
  variant = "add", 
  size = "default" 
}: FriendActionsProps) {
  const { toast } = useToast();
  const [status, setStatus] = useState(
    variant === "add" ? "Add Friend" : 
    variant === "accept" ? "Accept" : "Reject"
  );
  const currentUserId = authService.getState().user?.id;

  const addFriendMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/friends/addfriend", { 
        requesterId: currentUserId, 
        recipientId 
      });
      return response.json();
    },
    onSuccess: () => {
      setStatus("Request Sent");
      queryClient.invalidateQueries({ queryKey: ["/api/suggestions/users"] });
      queryClient.invalidateQueries({ queryKey: ["/api/connections/pending"] });
      toast({
        title: "Friend request sent!",
        description: "Your friend request has been sent successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message.includes("already exists") 
          ? "Friend request already exists" 
          : "Error sending friend request",
        variant: "destructive",
      });
    },
  });

  const acceptFriendMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/friends/acceptfriend", { requesterId });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/connections/pending"] });
      queryClient.invalidateQueries({ queryKey: ["/api/connections"] });
      queryClient.invalidateQueries({ queryKey: ["/api/suggestions/users"] });
      toast({
        title: "Friend request accepted!",
        description: "You are now connected!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Error accepting friend request",
        variant: "destructive",
      });
    },
  });

  const rejectFriendMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/friends/rejectfriend", { requesterId });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/connections/pending"] });
      queryClient.invalidateQueries({ queryKey: ["/api/suggestions/users"] });
      toast({
        title: "Friend request rejected",
        description: "The friend request has been declined.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Error rejecting friend request",
        variant: "destructive",
      });
    },
  });

  const handleAddFriend = () => {
    addFriendMutation.mutate();
  };

  const handleAcceptFriend = () => {
    acceptFriendMutation.mutate();
  };

  const handleRejectFriend = () => {
    rejectFriendMutation.mutate();
  };

  if (variant === "add") {
    return (
      <Button
        size={size}
        onClick={handleAddFriend}
        disabled={addFriendMutation.isPending}
        className="bg-connexta-blue hover:bg-connexta-navy text-white btn-add-friend"
      >
        <UserPlus className="w-4 h-4 mr-2" />
        {addFriendMutation.isPending ? "Sending..." : status}
      </Button>
    );
  }

  if (variant === "accept") {
    return (
      <Button
        size={size}
        onClick={handleAcceptFriend}
        disabled={acceptFriendMutation.isPending}
        className="bg-green-600 hover:bg-green-700 text-white"
      >
        <Check className="w-4 h-4 mr-2" />
        {acceptFriendMutation.isPending ? "Accepting..." : "Accept"}
      </Button>
    );
  }

  if (variant === "reject") {
    return (
      <Button
        size={size}
        variant="outline"
        onClick={handleRejectFriend}
        disabled={rejectFriendMutation.isPending}
        className="border-red-300 text-red-600 hover:bg-red-50"
      >
        <X className="w-4 h-4 mr-2" />
        {rejectFriendMutation.isPending ? "Rejecting..." : "Reject"}
      </Button>
    );
  }

  return null;
}