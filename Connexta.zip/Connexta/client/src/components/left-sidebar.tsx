import { Card, CardContent } from "@/components/ui/card";
import { authService } from "@/lib/auth";
import { Users, Eye, ThumbsUp, MessageCircle } from "lucide-react";
import ConnectionRequests from "./connection-requests";
import FollowStats from "./follow-stats";
import ProfilePicUpload from "./profile-pic-upload";

export default function LeftSidebar() {
  const authState = authService.getState();
  const user = authState.user;

  if (!user) return null;

  return (
    <aside className="space-y-6">
      {/* Connection Requests */}
      <ConnectionRequests />
      
      {/* Profile Card */}
      <Card className="overflow-hidden">
        <div className="h-16 bg-gradient-to-r from-[var(--connexta-blue)] to-[var(--connexta-light-blue)]"></div>
        <CardContent className="px-4 pb-4">
          <div className="flex flex-col items-center -mt-8">
            <ProfilePicUpload
              userId={user.id}
              onUploadComplete={() => {
                window.location.reload();
              }}
            >
              <div className="relative group">
                <img
                  src={user.avatar || user.profilePicture || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100"}
                  alt={`${user.firstName} ${user.lastName}`}
                  className="w-16 h-16 rounded-full border-4 border-white object-cover cursor-pointer transition-opacity group-hover:opacity-75"
                />
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity rounded-full">
                  <div className="bg-black bg-opacity-50 rounded-full p-1">
                    <span className="text-white text-xs">Change</span>
                  </div>
                </div>
              </div>
            </ProfilePicUpload>
            <h3 className="mt-2 text-lg font-semibold text-gray-900">
              {user.firstName} {user.lastName}
            </h3>
            <p className="text-sm text-gray-600 text-center">
              {user.headline || "Professional"}
            </p>
            {user.location && (
              <p className="text-xs text-gray-500 mt-1">{user.location}</p>
            )}
          </div>
          <div className="mt-4 pt-4 border-t border-gray-200">
            <div className="flex justify-between text-sm mb-3">
              <span className="text-gray-600">Profile viewers</span>
              <span className="connexta-blue font-medium">{user.profileViews || 0}</span>
            </div>
            <div className="flex justify-between text-sm mb-3">
              <span className="text-gray-600">Connections</span>
              <span className="connexta-blue font-medium">{user.connections || 0}</span>
            </div>
            <div className="pt-2 border-t border-gray-100">
              <FollowStats userId={user.id} showCards={false} />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card>
        <CardContent className="p-4">
          <h4 className="font-semibold text-gray-900 mb-3">Recent Activity</h4>
          <div className="space-y-3">
            <div className="flex items-start space-x-3">
              <ThumbsUp className="w-4 h-4 connexta-blue mt-1" />
              <div>
                <p className="text-sm text-gray-700">
                  You liked <span className="font-medium">Sarah Connor's</span> post
                </p>
                <p className="text-xs text-gray-500">2 hours ago</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <MessageCircle className="w-4 h-4 connexta-blue mt-1" />
              <div>
                <p className="text-sm text-gray-700">
                  You commented on <span className="font-medium">Tech Innovations</span>
                </p>
                <p className="text-xs text-gray-500">5 hours ago</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Groups */}
      <Card>
        <CardContent className="p-4">
          <h4 className="font-semibold text-gray-900 mb-3">Your Groups</h4>
          <div className="space-y-2">
            <a href="#" className="block text-sm text-gray-700 hover:text-connexta-blue">
              <Users className="inline w-4 h-4 mr-2" />
              Software Engineers Network
            </a>
            <a href="#" className="block text-sm text-gray-700 hover:text-connexta-blue">
              <Users className="inline w-4 h-4 mr-2" />
              Startup Founders
            </a>
            <a href="#" className="block text-sm text-gray-700 hover:text-connexta-blue">
              <Users className="inline w-4 h-4 mr-2" />
              Product Management
            </a>
          </div>
        </CardContent>
      </Card>
    </aside>
  );
}
