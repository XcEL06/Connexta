import { useState } from 'react';
import { useToast } from "@/hooks/use-toast";
import { authService } from "@/lib/auth";

interface ProfilePicUploadProps {
  userId?: number;
  onUploadComplete?: (imageUrl: string) => void;
  className?: string;
  children?: React.ReactNode;
}

const ProfilePicUpload = ({ userId, onUploadComplete, className, children }: ProfilePicUploadProps) => {
  const [image, setImage] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();
  
  const actualUserId = userId || authService.getState().user?.id;

  const uploadProfilePic = async () => {
    if (!image || !actualUserId) {
      toast({
        title: "Error",
        description: "Please select an image first",
        variant: "destructive",
      });
      return;
    }

    setIsUploading(true);
    const formData = new FormData();
    formData.append('image', image);
    
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`/api/upload/profilepic/${actualUserId}`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Upload failed');
      }

      const data = await response.json();
      toast({
        title: "Success",
        description: "Profile picture updated!",
      });

      if (onUploadComplete) {
        onUploadComplete(data.imageUrl);
      }

      setImage(null);
    } catch (err) {
      console.error('Upload failed', err);
      toast({
        title: "Error",
        description: "Upload failed. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type
      if (!file.type.startsWith('image/')) {
        toast({
          title: "Invalid file",
          description: "Please select an image file",
          variant: "destructive",
        });
        return;
      }

      // Validate file size (3MB limit)
      if (file.size > 3 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "File size must be less than 3MB",
          variant: "destructive",
        });
        return;
      }

      setImage(file);
    }
  };

  if (children) {
    return (
      <div className={className}>
        <input 
          type="file" 
          onChange={handleFileChange}
          accept="image/*"
          style={{ display: 'none' }}
          id={`profile-upload-${actualUserId}`}
        />
        <label 
          htmlFor={`profile-upload-${actualUserId}`}
          className="cursor-pointer"
        >
          {children}
        </label>
        {image && (
          <div className="mt-2">
            <button 
              onClick={uploadProfilePic}
              disabled={isUploading}
              className="bg-connexta-blue text-white px-3 py-1 rounded text-sm hover:bg-connexta-navy disabled:opacity-50"
            >
              {isUploading ? 'Uploading...' : 'Upload Profile Picture'}
            </button>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className={className}>
      <input 
        type="file" 
        onChange={handleFileChange}
        accept="image/*"
        className="mb-2"
      />
      <button 
        onClick={uploadProfilePic}
        disabled={!image || isUploading}
        className="bg-connexta-blue text-white px-4 py-2 rounded hover:bg-connexta-navy disabled:opacity-50"
      >
        {isUploading ? 'Uploading...' : 'Upload Profile Picture'}
      </button>
    </div>
  );
};

export default ProfilePicUpload;