import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { ThumbsUp, MessageCircle, Share, Send, MoreHorizontal } from "lucide-react";
import type { PostWithAuthor } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

interface PostCardProps {
  post: PostWithAuthor;
}

export default function PostCard({ post }: PostCardProps) {
  const { toast } = useToast();

  const { data: likeData } = useQuery({
    queryKey: ["/api/posts", post.id, "liked"],
  });

  const toggleLikeMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/posts/${post.id}/like`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/posts", post.id, "liked"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update like. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleLike = () => {
    toggleLikeMutation.mutate();
  };

  const isLiked = likeData?.liked || false;

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-start space-x-3">
          <img
            src={post.author.profilePicture || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50"}
            alt={`${post.author.firstName} ${post.author.lastName}`}
            className="w-12 h-12 rounded-full object-cover"
          />
          <div className="flex-1">
            <div className="flex items-center space-x-2">
              <h4 className="font-semibold text-gray-900">
                {post.author.firstName} {post.author.lastName}
              </h4>
              <span className="text-sm text-gray-500">•</span>
              <span className="text-sm text-gray-500">{post.author.headline}</span>
            </div>
            <p className="text-sm text-gray-500">
              {formatDistanceToNow(new Date(post.createdAt!), { addSuffix: true })}
            </p>
          </div>
          <Button variant="ghost" size="sm">
            <MoreHorizontal className="w-4 h-4" />
          </Button>
        </div>

        <div className="mt-4">
          <p className="text-gray-900 leading-relaxed whitespace-pre-wrap">
            {post.content}
          </p>
          
          {post.imageUrl && (
            <img
              src={post.imageUrl}
              alt="Post content"
              className="mt-4 rounded-lg w-full max-h-96 object-cover"
            />
          )}
        </div>

        <div className="mt-4 pt-4 border-t border-gray-200">
          <div className="flex items-center justify-between text-sm text-gray-500 mb-3">
            <div className="flex items-center space-x-4">
              <span>
                <ThumbsUp className="inline w-4 h-4 connexta-blue mr-1" />
                {post.likes} likes
              </span>
              <span>{post.comments} comments</span>
              <span>{post.shares} shares</span>
            </div>
          </div>
          
          <div className="flex justify-between">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLike}
              disabled={toggleLikeMutation.isPending}
              className={`flex items-center space-x-2 px-4 py-2 hover:bg-gray-50 rounded-md transition-colors ${
                isLiked ? "text-connexta-blue" : "text-gray-600"
              }`}
            >
              <ThumbsUp className={`w-4 h-4 ${isLiked ? "fill-current" : ""}`} />
              <span className="text-sm font-medium">Like</span>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
              <span className="text-sm font-medium">Comment</span>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md transition-colors"
            >
              <Share className="w-4 h-4" />
              <span className="text-sm font-medium">Share</span>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md transition-colors"
            >
              <Send className="w-4 h-4" />
              <span className="text-sm font-medium">Send</span>
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
