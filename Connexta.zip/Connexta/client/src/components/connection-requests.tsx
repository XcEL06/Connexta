import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Clock } from "lucide-react";
import type { Connection, UserProfile } from "@shared/schema";
import FriendActions from "./friend-actions";

type ConnectionWithRequester = Connection & { requester: UserProfile };
type ConnectionWithRecipient = Connection & { recipient: UserProfile };

export default function ConnectionRequests() {
  const { data: pendingRequests = [] } = useQuery<ConnectionWithRequester[]>({
    queryKey: ["/api/connections/pending"],
  });

  const { data: sentRequests = [] } = useQuery<ConnectionWithRecipient[]>({
    queryKey: ["/api/connections/sent"],
  });

  if (pendingRequests.length === 0 && sentRequests.length === 0) {
    return null;
  }

  return (
    <div className="space-y-6">
      {/* Pending Requests (Received) */}
      {pendingRequests.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <Check className="w-5 h-5 mr-2 text-green-600" />
              Connection Requests
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {pendingRequests.map((request) => (
              <div key={request.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <img
                    src={request.requester.profilePicture || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40"}
                    alt={`${request.requester.firstName} ${request.requester.lastName}`}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <div>
                    <p className="font-medium text-gray-900">
                      {request.requester.firstName} {request.requester.lastName}
                    </p>
                    <p className="text-sm text-gray-500">{request.requester.headline}</p>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <FriendActions 
                    recipientId={request.recipientId}
                    requesterId={request.requesterId}
                    variant="accept"
                    size="sm"
                  />
                  <FriendActions 
                    recipientId={request.recipientId}
                    requesterId={request.requesterId}
                    variant="reject"
                    size="sm"
                  />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Sent Requests */}
      {sentRequests.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <Clock className="w-5 h-5 mr-2 text-yellow-600" />
              Sent Requests
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {sentRequests.map((request) => (
              <div key={request.id} className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <img
                    src={request.recipient.profilePicture || "https://images.unsplash.com/photo-1494790108755-2616b332c98c?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40"}
                    alt={`${request.recipient.firstName} ${request.recipient.lastName}`}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <div>
                    <p className="font-medium text-gray-900">
                      {request.recipient.firstName} {request.recipient.lastName}
                    </p>
                    <p className="text-sm text-gray-500">{request.recipient.headline}</p>
                  </div>
                </div>
                <div className="flex items-center text-yellow-600">
                  <Clock className="w-4 h-4 mr-1" />
                  <span className="text-sm">Pending</span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}