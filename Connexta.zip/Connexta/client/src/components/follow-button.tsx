import { useState, useEffect } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { UserPlus, UserMinus } from "lucide-react";

interface FollowButtonProps {
  userId: number;
  size?: "sm" | "default" | "lg";
  variant?: "default" | "outline" | "ghost";
}

export default function FollowButton({ userId, size = "default", variant = "default" }: FollowButtonProps) {
  const { toast } = useToast();

  const { data: followStatus } = useQuery({
    queryKey: ["/api/follow/check", userId],
    queryFn: async () => {
      const currentUserId = authService.getState().user?.id;
      if (!currentUserId) return { isFollowing: false };
      const response = await apiRequest("GET", `/api/follow/check?followerId=${currentUserId}&followingId=${userId}`, undefined);
      return response.json();
    },
  });

  const followMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/follow/follow", { 
        followerId: null, // Let server use authenticated user
        followingId: userId 
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/follow/check", userId] });
      queryClient.invalidateQueries({ queryKey: ["/api/follow/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/suggestions/users"] });
      toast({
        title: "Following user",
        description: "You are now following this user.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to follow user",
        variant: "destructive",
      });
    },
  });

  const unfollowMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/follow/unfollow", { 
        followerId: null, // Let server use authenticated user
        followingId: userId 
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/follow/check", userId] });
      queryClient.invalidateQueries({ queryKey: ["/api/follow/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/suggestions/users"] });
      toast({
        title: "Unfollowed user",
        description: "You are no longer following this user.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to unfollow user",
        variant: "destructive",
      });
    },
  });

  const isFollowing = followStatus?.isFollowing || false;
  const isLoading = followMutation.isPending || unfollowMutation.isPending;

  const handleClick = () => {
    if (isFollowing) {
      unfollowMutation.mutate();
    } else {
      followMutation.mutate();
    }
  };

  return (
    <Button
      onClick={handleClick}
      disabled={isLoading}
      size={size}
      variant={isFollowing ? "outline" : variant}
      className={
        isFollowing 
          ? "border-gray-300 text-gray-700 hover:bg-red-50 hover:border-red-300 hover:text-red-700"
          : "bg-connexta-blue hover:bg-connexta-navy text-white"
      }
    >
      {isFollowing ? (
        <>
          <UserMinus className="w-4 h-4 mr-2" />
          {isLoading ? "Unfollowing..." : "Unfollow"}
        </>
      ) : (
        <>
          <UserPlus className="w-4 h-4 mr-2" />
          {isLoading ? "Following..." : "Follow"}
        </>
      )}
    </Button>
  );
}