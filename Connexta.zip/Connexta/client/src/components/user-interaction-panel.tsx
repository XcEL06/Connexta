import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import AddFriendButton from "./add-friend-button";
import FollowButton from "./follow-actions";
import { authService } from "@/lib/auth";
import type { UserProfile } from "@shared/schema";

interface UserInteractionPanelProps {
  users: UserProfile[];
  title?: string;
}

export default function UserInteractionPanel({ 
  users, 
  title = "People You May Know" 
}: UserInteractionPanelProps) {
  const currentUserId = authService.getState().user?.id;
  
  if (users.length === 0) return null;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">{title}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {users.map((user) => (
          <div key={user.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <img
                src={user.profilePicture || "https://images.unsplash.com/photo-1519345182560-3f2917c472ef?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40"}
                alt={`${user.firstName} ${user.lastName}`}
                className="w-10 h-10 rounded-full object-cover"
              />
              <div>
                <p className="font-medium text-gray-900">
                  {user.firstName} {user.lastName}
                </p>
                <p className="text-sm text-gray-500">{user.headline}</p>
              </div>
            </div>
            <div className="flex space-x-2">
              <AddFriendButton 
                targetUserId={user.id}
                className="btn-add-friend text-xs px-3 py-1"
              />
              <FollowButton 
                currentUserId={currentUserId}
                targetUserId={user.id}
                className="btn-follow text-xs px-3 py-1"
              />
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}