import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { authService } from "@/lib/auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import PostCard from "./post-card";
import { Image, Video, FileText, BarChart3 } from "lucide-react";
import type { PostWithAuthor } from "@shared/schema";

export default function MainFeed() {
  const { toast } = useToast();
  const [postContent, setPostContent] = useState("");
  const [isCreatingPost, setIsCreatingPost] = useState(false);
  const authState = authService.getState();
  const user = authState.user;

  const { data: posts = [], isLoading } = useQuery<PostWithAuthor[]>({
    queryKey: ["/api/posts"],
  });

  const createPostMutation = useMutation({
    mutationFn: async (content: string) => {
      const response = await apiRequest("POST", "/api/posts", { content });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      setPostContent("");
      setIsCreatingPost(false);
      toast({
        title: "Post created!",
        description: "Your post has been shared successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create post. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmitPost = () => {
    if (!postContent.trim()) return;
    createPostMutation.mutate(postContent);
  };

  if (!user) return null;

  return (
    <div className="space-y-6">
      {/* Post Creation */}
      <Card>
        <CardContent className="p-4">
          {isCreatingPost ? (
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <img
                  src={user.profilePicture || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50"}
                  alt="Your profile"
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div>
                  <h4 className="font-medium">{user.firstName} {user.lastName}</h4>
                  <p className="text-sm text-gray-500">Post to anyone</p>
                </div>
              </div>
              <Textarea
                placeholder="What do you want to talk about?"
                value={postContent}
                onChange={(e) => setPostContent(e.target.value)}
                className="min-h-[120px] border-none resize-none focus:ring-0 text-lg placeholder:text-gray-400"
                autoFocus
              />
              <div className="flex justify-between items-center">
                <div className="flex space-x-4">
                  <Button variant="ghost" size="sm" className="text-gray-600 hover:text-connexta-blue">
                    <Image className="w-5 h-5 mr-2" />
                    Photo
                  </Button>
                  <Button variant="ghost" size="sm" className="text-gray-600 hover:text-connexta-blue">
                    <Video className="w-5 h-5 mr-2" />
                    Video
                  </Button>
                  <Button variant="ghost" size="sm" className="text-gray-600 hover:text-connexta-blue">
                    <FileText className="w-5 h-5 mr-2" />
                    Document
                  </Button>
                </div>
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setIsCreatingPost(false);
                      setPostContent("");
                    }}
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={handleSubmitPost}
                    disabled={!postContent.trim() || createPostMutation.isPending}
                    className="bg-connexta-blue hover:bg-connexta-navy"
                  >
                    {createPostMutation.isPending ? "Posting..." : "Post"}
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            <>
              <div className="flex items-center space-x-3">
                <img
                  src={user.profilePicture || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50"}
                  alt="Your profile"
                  className="w-12 h-12 rounded-full object-cover"
                />
                <Button
                  variant="outline"
                  className="flex-1 justify-start text-gray-600 hover:bg-gray-100"
                  onClick={() => setIsCreatingPost(true)}
                >
                  Share your thoughts...
                </Button>
              </div>
              <div className="flex justify-between mt-4 pt-4 border-t border-gray-200">
                <Button variant="ghost" size="sm" className="text-gray-600 hover:text-connexta-blue">
                  <Image className="w-5 h-5 mr-2" />
                  Photo
                </Button>
                <Button variant="ghost" size="sm" className="text-gray-600 hover:text-connexta-blue">
                  <Video className="w-5 h-5 mr-2" />
                  Video
                </Button>
                <Button variant="ghost" size="sm" className="text-gray-600 hover:text-connexta-blue">
                  <FileText className="w-5 h-5 mr-2" />
                  Document
                </Button>
                <Button variant="ghost" size="sm" className="text-gray-600 hover:text-connexta-blue">
                  <BarChart3 className="w-5 h-5 mr-2" />
                  Poll
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Feed Posts */}
      {isLoading ? (
        <div className="space-y-6">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardContent className="p-4">
                <div className="animate-pulse">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="w-12 h-12 bg-gray-200 rounded-full"></div>
                    <div className="space-y-2">
                      <div className="h-4 bg-gray-200 rounded w-32"></div>
                      <div className="h-3 bg-gray-200 rounded w-24"></div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="h-4 bg-gray-200 rounded"></div>
                    <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="space-y-6">
          {posts.map((post) => (
            <PostCard key={post.id} post={post} />
          ))}
        </div>
      )}
    </div>
  );
}
