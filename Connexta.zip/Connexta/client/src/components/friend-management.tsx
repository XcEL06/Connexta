import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { authService } from "@/lib/auth";
import type { Connection, UserProfile } from "@shared/schema";
import AddFriendButton from "./add-friend-button";

type ConnectionWithRequester = Connection & { requester: UserProfile };

const AcceptFriendButton = ({ requesterId }: { requesterId: number }) => {
  const [status, setStatus] = useState("Accept");
  const { toast } = useToast();

  const handleAcceptFriend = async () => {
    try {
      await apiRequest("POST", "/api/friends/acceptfriend", { requesterId });
      setStatus("Accepted");
      toast({
        title: "Friend request accepted!",
        description: "You are now connected!",
      });
    } catch (error) {
      console.error("Error accepting friend", error);
      toast({
        title: "Error",
        description: "Error accepting friend request",
        variant: "destructive",
      });
    }
  };

  return (
    <button 
      onClick={handleAcceptFriend} 
      className="btn-add-friend bg-green-600 hover:bg-green-700"
      style={{ backgroundColor: status === "Accepted" ? "#16a34a" : "#16a34a" }}
    >
      {status}
    </button>
  );
};

const RejectFriendButton = ({ requesterId }: { requesterId: number }) => {
  const [status, setStatus] = useState("Reject");
  const { toast } = useToast();

  const handleRejectFriend = async () => {
    try {
      await apiRequest("POST", "/api/friends/rejectfriend", { requesterId });
      setStatus("Rejected");
      toast({
        title: "Friend request rejected",
        description: "The friend request has been declined.",
      });
    } catch (error) {
      console.error("Error rejecting friend", error);
      toast({
        title: "Error",
        description: "Error rejecting friend request",
        variant: "destructive",
      });
    }
  };

  return (
    <button 
      onClick={handleRejectFriend} 
      className="btn-add-friend bg-red-600 hover:bg-red-700"
      style={{ backgroundColor: "#dc2626" }}
    >
      {status}
    </button>
  );
};

export default function FriendManagement() {
  const { data: pendingRequests = [] } = useQuery<ConnectionWithRequester[]>({
    queryKey: ["/api/connections/pending"],
  });

  const { data: suggestedUsers = [] } = useQuery<UserProfile[]>({
    queryKey: ["/api/suggestions/users"],
  });

  const currentUserId = authService.getState().user?.id;

  if (!currentUserId) return null;

  return (
    <div className="space-y-6">
      {/* Pending Friend Requests */}
      {pendingRequests.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Friend Requests</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {pendingRequests.map((request) => (
              <div key={request.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <img
                    src={request.requester.profilePicture || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40"}
                    alt={`${request.requester.firstName} ${request.requester.lastName}`}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <div>
                    <p className="font-medium text-gray-900">
                      {request.requester.firstName} {request.requester.lastName}
                    </p>
                    <p className="text-sm text-gray-500">{request.requester.headline}</p>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <AcceptFriendButton requesterId={request.requesterId} />
                  <RejectFriendButton requesterId={request.requesterId} />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Suggested Friends */}
      {suggestedUsers.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">People You May Know</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {suggestedUsers.map((user) => (
              <div key={user.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <img
                    src={user.profilePicture || "https://images.unsplash.com/photo-1519345182560-3f2917c472ef?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40"}
                    alt={`${user.firstName} ${user.lastName}`}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <div>
                    <p className="font-medium text-gray-900">
                      {user.firstName} {user.lastName}
                    </p>
                    <p className="text-sm text-gray-500">{user.headline}</p>
                  </div>
                </div>
                <AddFriendButton targetUserId={user.id} />
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}