import { Card, CardContent } from "@/components/ui/card";
import { authService } from "@/lib/auth";
import FollowStats from "./follow-stats";
import ProfilePicUpload from "./profile-pic-upload";
import type { UserProfile } from "@shared/schema";

interface UserProfileCardProps {
  userProfile: UserProfile;
  isOwnProfile?: boolean;
}

export default function UserProfileCard({ userProfile, isOwnProfile = false }: UserProfileCardProps) {
  const currentUser = authService.getState().user;

  return (
    <Card className="overflow-hidden">
      <div className="h-32 bg-gradient-to-r from-[var(--connexta-blue)] to-[var(--connexta-light-blue)]"></div>
      <CardContent className="px-6 pb-6">
        <div className="flex flex-col items-center -mt-16">
          {isOwnProfile ? (
            <ProfilePicUpload
              userId={userProfile.id}
              onUploadComplete={() => {
                window.location.reload();
              }}
            >
              <div className="relative group">
                <img
                  src={userProfile.avatar || userProfile.profilePicture || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=120&h=120"}
                  alt={`${userProfile.firstName} ${userProfile.lastName}`}
                  className="w-32 h-32 rounded-full border-4 border-white object-cover cursor-pointer transition-opacity group-hover:opacity-75"
                />
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity rounded-full">
                  <div className="bg-black bg-opacity-50 rounded-full p-2">
                    <span className="text-white text-sm">Change Photo</span>
                  </div>
                </div>
              </div>
            </ProfilePicUpload>
          ) : (
            <img
              src={userProfile.avatar || userProfile.profilePicture || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=120&h=120"}
              alt={`${userProfile.firstName} ${userProfile.lastName}`}
              className="w-32 h-32 rounded-full border-4 border-white object-cover"
            />
          )}
          
          <h2 className="mt-4 text-2xl font-bold text-gray-900">
            {userProfile.firstName} {userProfile.lastName}
          </h2>
          
          <p className="text-lg text-gray-600 text-center mt-1">
            {userProfile.headline || "Professional"}
          </p>
          
          {userProfile.location && (
            <p className="text-sm text-gray-500 mt-1">{userProfile.location}</p>
          )}

          <div className="mt-6 w-full">
            <FollowStats userId={userProfile.id} showCards={false} />
          </div>

          <div className="mt-6 pt-6 border-t border-gray-200 w-full">
            <div className="grid grid-cols-2 gap-4 text-center">
              <div>
                <p className="text-2xl font-bold connexta-blue">{userProfile.profileViews || 0}</p>
                <p className="text-sm text-gray-600">Profile Views</p>
              </div>
              <div>
                <p className="text-2xl font-bold connexta-blue">{userProfile.connections || 0}</p>
                <p className="text-sm text-gray-600">Connections</p>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}