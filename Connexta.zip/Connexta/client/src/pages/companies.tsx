import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Building, Users, MapPin, Globe, Star, Plus, Search, Briefcase, TrendingUp } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { authService } from "@/lib/auth";

interface Company {
  id: number;
  name: string;
  description: string;
  industry: string;
  size: string;
  website?: string;
  location: string;
  logoUrl?: string;
  coverImageUrl?: string;
  foundedYear?: number;
  employeeCount: number;
  openJobs: number;
  isFollowing: boolean;
  rating: number;
  reviews: number;
}

interface CompanyEmployee {
  id: number;
  firstName: string;
  lastName: string;
  headline: string;
  profilePicture?: string;
  position: string;
  isConnection: boolean;
}

export default function CompaniesPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedIndustry, setSelectedIndustry] = useState("all");
  const [selectedSize, setSelectedSize] = useState("all");
  const queryClient = useQueryClient();
  const user = authService.getState().user;

  const { data: companies = [] } = useQuery<Company[]>({
    queryKey: ["/api/companies"],
  });

  const { data: followingCompanies = [] } = useQuery<Company[]>({
    queryKey: ["/api/companies/following"],
    enabled: !!user,
  });

  const followCompanyMutation = useMutation({
    mutationFn: (companyId: number) =>
      apiRequest(`/api/companies/${companyId}/follow`, "POST"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/companies"] });
    },
  });

  const industries = ["all", "Technology", "Finance", "Healthcare", "Marketing", "Education", "Manufacturing", "Retail"];
  const companySizes = ["all", "startup", "small", "medium", "large", "enterprise"];

  const filteredCompanies = companies.filter(company => {
    const matchesSearch = company.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         company.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesIndustry = selectedIndustry === "all" || company.industry === selectedIndustry;
    const matchesSize = selectedSize === "all" || company.size === selectedSize;
    return matchesSearch && matchesIndustry && matchesSize;
  });

  const getSizeLabel = (size: string) => {
    switch (size) {
      case "startup": return "1-10 employees";
      case "small": return "11-50 employees";
      case "medium": return "51-200 employees";
      case "large": return "201-1000 employees";
      case "enterprise": return "1000+ employees";
      default: return "Unknown size";
    }
  };

  const getSizeColor = (size: string) => {
    switch (size) {
      case "startup": return "bg-green-100 text-green-800";
      case "small": return "bg-blue-100 text-blue-800";
      case "medium": return "bg-yellow-100 text-yellow-800";
      case "large": return "bg-orange-100 text-orange-800";
      case "enterprise": return "bg-purple-100 text-purple-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Companies</h1>
          <p className="text-gray-600 mt-2">Discover companies, follow updates, and explore opportunities</p>
        </div>
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          Add Company
        </Button>
      </div>

      <Tabs defaultValue="discover" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="discover">Discover Companies</TabsTrigger>
          <TabsTrigger value="following">Following ({followingCompanies.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="discover" className="space-y-6">
          {/* Search and Filters */}
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search companies..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2 overflow-x-auto">
              {industries.map((industry) => (
                <Button
                  key={industry}
                  variant={selectedIndustry === industry ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedIndustry(industry)}
                  className="whitespace-nowrap"
                >
                  {industry}
                </Button>
              ))}
            </div>
            <div className="flex gap-2 overflow-x-auto">
              {companySizes.map((size) => (
                <Button
                  key={size}
                  variant={selectedSize === size ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedSize(size)}
                  className="whitespace-nowrap capitalize"
                >
                  {size}
                </Button>
              ))}
            </div>
          </div>

          {/* Companies Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCompanies.map((company) => (
              <Card key={company.id} className="hover:shadow-lg transition-shadow">
                {company.coverImageUrl && (
                  <div className="h-32 bg-gray-200 rounded-t-lg overflow-hidden">
                    <img
                      src={company.coverImageUrl}
                      alt={company.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                <CardHeader className="pb-3">
                  <div className="flex items-start gap-3">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={company.logoUrl} />
                      <AvatarFallback>
                        <Building className="w-6 h-6" />
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <CardTitle className="text-lg">{company.name}</CardTitle>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="secondary">{company.industry}</Badge>
                        <Badge className={getSizeColor(company.size)}>
                          {getSizeLabel(company.size)}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-gray-600 line-clamp-3">
                    {company.description}
                  </p>

                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2 text-gray-600">
                      <MapPin className="w-4 h-4" />
                      {company.location}
                    </div>
                    <div className="flex items-center gap-2 text-gray-600">
                      <Users className="w-4 h-4" />
                      {company.employeeCount.toLocaleString()} employees
                    </div>
                    <div className="flex items-center gap-2 text-gray-600">
                      <Briefcase className="w-4 h-4" />
                      {company.openJobs} open positions
                    </div>
                    {company.website && (
                      <div className="flex items-center gap-2 text-gray-600">
                        <Globe className="w-4 h-4" />
                        <a
                          href={company.website}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="hover:text-blue-600 truncate"
                        >
                          {company.website}
                        </a>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-yellow-500 fill-current" />
                      <span className="text-sm font-medium">{company.rating.toFixed(1)}</span>
                      <span className="text-xs text-gray-500">({company.reviews} reviews)</span>
                    </div>
                    {company.foundedYear && (
                      <span className="text-xs text-gray-500">Founded {company.foundedYear}</span>
                    )}
                  </div>

                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant={company.isFollowing ? "outline" : "default"}
                      onClick={() => !company.isFollowing && followCompanyMutation.mutate(company.id)}
                      disabled={followCompanyMutation.isPending}
                      className="flex-1"
                    >
                      {company.isFollowing ? "Following" : "Follow"}
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1">
                      View Jobs
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="following" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {followingCompanies.map((company) => (
              <Card key={company.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-start gap-3">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={company.logoUrl} />
                      <AvatarFallback>
                        <Building className="w-6 h-6" />
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <CardTitle className="text-lg">{company.name}</CardTitle>
                      <Badge variant="secondary">{company.industry}</Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between text-sm text-gray-600">
                    <div className="flex items-center gap-1">
                      <Users className="w-4 h-4" />
                      {company.employeeCount.toLocaleString()}
                    </div>
                    <div className="flex items-center gap-1">
                      <Briefcase className="w-4 h-4" />
                      {company.openJobs} jobs
                    </div>
                    <div className="flex items-center gap-1">
                      <TrendingUp className="w-4 h-4" />
                      {company.rating.toFixed(1)}
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" className="flex-1">
                      View Updates
                    </Button>
                    <Button size="sm" className="flex-1">
                      View Jobs
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {followingCompanies.length === 0 && (
            <div className="text-center py-12">
              <div className="w-24 h-24 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
                <Building className="w-12 h-12 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Not following any companies yet</h3>
              <p className="text-gray-600 mb-4">Follow companies to stay updated on their news and job openings</p>
              <Button>
                <Search className="w-4 h-4 mr-2" />
                Discover Companies
              </Button>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}