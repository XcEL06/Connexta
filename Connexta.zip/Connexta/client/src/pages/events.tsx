import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar, Clock, MapPin, Users, Video, Plus, Search, Star } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { authService } from "@/lib/auth";
import { format } from "date-fns";

interface Event {
  id: number;
  title: string;
  description: string;
  eventType: string;
  location?: string;
  isOnline: boolean;
  eventUrl?: string;
  startDate: string;
  endDate: string;
  maxAttendees?: number;
  currentAttendees: number;
  imageUrl?: string;
  isAttending: boolean;
  createdBy: {
    id: number;
    firstName: string;
    lastName: string;
    profilePicture?: string;
  };
}

export default function EventsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedType, setSelectedType] = useState("all");
  const queryClient = useQueryClient();
  const user = authService.getState().user;

  const { data: upcomingEvents = [] } = useQuery<Event[]>({
    queryKey: ["/api/events/upcoming"],
  });

  const { data: myEvents = [] } = useQuery<Event[]>({
    queryKey: ["/api/events/attending"],
    enabled: !!user,
  });

  const attendEventMutation = useMutation({
    mutationFn: (eventId: number) =>
      apiRequest(`/api/events/${eventId}/attend`, "POST"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
    },
  });

  const eventTypes = ["all", "networking", "conference", "workshop", "webinar"];

  const filteredEvents = upcomingEvents.filter(event => {
    const matchesSearch = event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         event.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = selectedType === "all" || event.eventType === selectedType;
    return matchesSearch && matchesType;
  });

  const getEventTypeIcon = (type: string) => {
    switch (type) {
      case "webinar":
        return <Video className="w-4 h-4" />;
      case "networking":
        return <Users className="w-4 h-4" />;
      case "conference":
        return <Star className="w-4 h-4" />;
      default:
        return <Calendar className="w-4 h-4" />;
    }
  };

  const getEventTypeColor = (type: string) => {
    switch (type) {
      case "webinar":
        return "bg-blue-100 text-blue-800";
      case "networking":
        return "bg-green-100 text-green-800";
      case "conference":
        return "bg-purple-100 text-purple-800";
      case "workshop":
        return "bg-orange-100 text-orange-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Professional Events</h1>
          <p className="text-gray-600 mt-2">Discover networking events, conferences, and workshops</p>
        </div>
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          Create Event
        </Button>
      </div>

      <Tabs defaultValue="discover" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="discover">Discover Events</TabsTrigger>
          <TabsTrigger value="my-events">My Events ({myEvents.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="discover" className="space-y-6">
          {/* Search and Filter */}
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search events..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              {eventTypes.map((type) => (
                <Button
                  key={type}
                  variant={selectedType === type ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedType(type)}
                  className="capitalize"
                >
                  {type}
                </Button>
              ))}
            </div>
          </div>

          {/* Events Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredEvents.map((event) => (
              <Card key={event.id} className="hover:shadow-lg transition-shadow">
                {event.imageUrl && (
                  <div className="h-48 bg-gray-200 rounded-t-lg overflow-hidden">
                    <img
                      src={event.imageUrl}
                      alt={event.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <CardTitle className="text-lg line-clamp-2">{event.title}</CardTitle>
                    <Badge className={`${getEventTypeColor(event.eventType)} flex items-center gap-1`}>
                      {getEventTypeIcon(event.eventType)}
                      {event.eventType}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-gray-600 line-clamp-3">
                    {event.description}
                  </p>

                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2 text-gray-600">
                      <Calendar className="w-4 h-4" />
                      {format(new Date(event.startDate), "MMM dd, yyyy")}
                    </div>
                    <div className="flex items-center gap-2 text-gray-600">
                      <Clock className="w-4 h-4" />
                      {format(new Date(event.startDate), "h:mm a")} - {format(new Date(event.endDate), "h:mm a")}
                    </div>
                    <div className="flex items-center gap-2 text-gray-600">
                      {event.isOnline ? (
                        <>
                          <Video className="w-4 h-4" />
                          Online Event
                        </>
                      ) : (
                        <>
                          <MapPin className="w-4 h-4" />
                          {event.location || "Location TBD"}
                        </>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-gray-600">
                      <Users className="w-4 h-4" />
                      {event.currentAttendees} attending
                      {event.maxAttendees && ` / ${event.maxAttendees} max`}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Avatar className="w-6 h-6">
                      <AvatarImage src={event.createdBy.profilePicture} />
                      <AvatarFallback className="text-xs">
                        {event.createdBy.firstName[0]}{event.createdBy.lastName[0]}
                      </AvatarFallback>
                    </Avatar>
                    <span className="text-xs text-gray-500">
                      Hosted by {event.createdBy.firstName} {event.createdBy.lastName}
                    </span>
                  </div>

                  <Button
                    size="sm"
                    className="w-full"
                    variant={event.isAttending ? "outline" : "default"}
                    onClick={() => !event.isAttending && attendEventMutation.mutate(event.id)}
                    disabled={attendEventMutation.isPending}
                  >
                    {event.isAttending ? "Going" : "Attend Event"}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="my-events" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {myEvents.map((event) => (
              <Card key={event.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">{event.title}</CardTitle>
                  <Badge className={`${getEventTypeColor(event.eventType)} flex items-center gap-1 w-fit`}>
                    {getEventTypeIcon(event.eventType)}
                    {event.eventType}
                  </Badge>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2 text-gray-600">
                      <Calendar className="w-4 h-4" />
                      {format(new Date(event.startDate), "MMM dd, yyyy")}
                    </div>
                    <div className="flex items-center gap-2 text-gray-600">
                      <Clock className="w-4 h-4" />
                      {format(new Date(event.startDate), "h:mm a")}
                    </div>
                    <div className="flex items-center gap-2 text-gray-600">
                      {event.isOnline ? (
                        <>
                          <Video className="w-4 h-4" />
                          Online Event
                        </>
                      ) : (
                        <>
                          <MapPin className="w-4 h-4" />
                          {event.location}
                        </>
                      )}
                    </div>
                  </div>

                  <Button size="sm" className="w-full">
                    View Event Details
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {myEvents.length === 0 && (
            <div className="text-center py-12">
              <div className="w-24 h-24 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
                <Calendar className="w-12 h-12 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold mb-2">No events registered</h3>
              <p className="text-gray-600 mb-4">Discover and register for professional events to expand your network</p>
              <Button>
                <Search className="w-4 h-4 mr-2" />
                Browse Events
              </Button>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}