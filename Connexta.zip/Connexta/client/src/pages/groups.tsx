import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Search, Users, MessageCircle, Calendar, Globe, Lock, UserPlus } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { authService } from "@/lib/auth";

interface Group {
  id: number;
  name: string;
  description: string;
  category: string;
  privacy: string;
  coverImageUrl?: string;
  memberCount: number;
  isJoined: boolean;
  createdBy: {
    id: number;
    firstName: string;
    lastName: string;
    profilePicture?: string;
  };
}

export default function GroupsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const queryClient = useQueryClient();
  const user = authService.getState().user;

  const { data: discoveryGroups = [] } = useQuery<Group[]>({
    queryKey: ["/api/groups/discover"],
  });

  const { data: myGroups = [] } = useQuery<Group[]>({
    queryKey: ["/api/groups/my"],
    enabled: !!user,
  });

  const joinGroupMutation = useMutation({
    mutationFn: (groupId: number) =>
      apiRequest(`/api/groups/${groupId}/join`, "POST"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/groups"] });
    },
  });

  const categories = ["all", "Technology", "Business", "Marketing", "Design", "Engineering", "Healthcare", "Finance"];

  const filteredGroups = discoveryGroups.filter(group => {
    const matchesSearch = group.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         group.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "all" || group.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Professional Groups</h1>
          <p className="text-gray-600 mt-2">Connect with like-minded professionals and grow your network</p>
        </div>
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          Create Group
        </Button>
      </div>

      <Tabs defaultValue="discover" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="discover">Discover Groups</TabsTrigger>
          <TabsTrigger value="my-groups">My Groups ({myGroups.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="discover" className="space-y-6">
          {/* Search and Filter */}
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search groups..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2 overflow-x-auto">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                  className="whitespace-nowrap"
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>

          {/* Groups Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredGroups.map((group) => (
              <Card key={group.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-lg mb-1">{group.name}</CardTitle>
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="secondary">{group.category}</Badge>
                        <div className="flex items-center gap-1 text-sm text-gray-500">
                          {group.privacy === "public" ? (
                            <Globe className="w-3 h-3" />
                          ) : (
                            <Lock className="w-3 h-3" />
                          )}
                          {group.privacy}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-gray-600 line-clamp-3">
                    {group.description}
                  </p>

                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-1 text-gray-500">
                      <Users className="w-4 h-4" />
                      {group.memberCount} members
                    </div>
                    <div className="flex items-center gap-1 text-gray-500">
                      <MessageCircle className="w-4 h-4" />
                      Active today
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Avatar className="w-6 h-6">
                      <AvatarImage src={group.createdBy.profilePicture} />
                      <AvatarFallback className="text-xs">
                        {group.createdBy.firstName[0]}{group.createdBy.lastName[0]}
                      </AvatarFallback>
                    </Avatar>
                    <span className="text-xs text-gray-500">
                      Created by {group.createdBy.firstName} {group.createdBy.lastName}
                    </span>
                  </div>

                  <Button
                    size="sm"
                    className="w-full"
                    variant={group.isJoined ? "outline" : "default"}
                    onClick={() => !group.isJoined && joinGroupMutation.mutate(group.id)}
                    disabled={joinGroupMutation.isPending}
                  >
                    {group.isJoined ? (
                      <>
                        <MessageCircle className="w-4 h-4 mr-2" />
                        View Group
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-4 h-4 mr-2" />
                        Join Group
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="my-groups" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {myGroups.map((group) => (
              <Card key={group.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">{group.name}</CardTitle>
                  <Badge variant="secondary">{group.category}</Badge>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-gray-600 line-clamp-2">
                    {group.description}
                  </p>

                  <div className="flex items-center justify-between text-sm text-gray-500">
                    <div className="flex items-center gap-1">
                      <Users className="w-4 h-4" />
                      {group.memberCount} members
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      Last visit: 2 days ago
                    </div>
                  </div>

                  <Button size="sm" className="w-full">
                    <MessageCircle className="w-4 h-4 mr-2" />
                    View Discussions
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {myGroups.length === 0 && (
            <div className="text-center py-12">
              <div className="w-24 h-24 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
                <Users className="w-12 h-12 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold mb-2">You haven't joined any groups yet</h3>
              <p className="text-gray-600 mb-4">Join professional groups to connect with peers and share knowledge</p>
              <Button>
                <Search className="w-4 h-4 mr-2" />
                Discover Groups
              </Button>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}