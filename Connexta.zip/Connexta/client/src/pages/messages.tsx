import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Send, Search, Plus, MoreHorizontal, Paperclip, Smile } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { authService } from "@/lib/auth";
import { format } from "date-fns";

interface Conversation {
  id: number;
  type: "direct" | "group";
  name?: string;
  participants: Array<{
    id: number;
    firstName: string;
    lastName: string;
    profilePicture?: string;
    headline?: string;
  }>;
  lastMessage?: {
    content: string;
    createdAt: string;
    senderId: number;
  };
  unreadCount: number;
}

interface Message {
  id: number;
  content: string;
  messageType: "text" | "image" | "file";
  attachmentUrl?: string;
  senderId: number;
  sender: {
    id: number;
    firstName: string;
    lastName: string;
    profilePicture?: string;
  };
  createdAt: string;
  isRead: boolean;
}

export default function MessagesPage() {
  const [selectedConversation, setSelectedConversation] = useState<number | null>(null);
  const [newMessage, setNewMessage] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();
  const user = authService.getState().user;

  const { data: conversations = [] } = useQuery<Conversation[]>({
    queryKey: ["/api/conversations"],
    enabled: !!user,
  });

  const { data: messages = [] } = useQuery<Message[]>({
    queryKey: ["/api/conversations", selectedConversation, "messages"],
    enabled: !!selectedConversation,
  });

  const sendMessageMutation = useMutation({
    mutationFn: (data: { conversationId: number; content: string }) =>
      apiRequest("/api/messages", "POST", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
      setNewMessage("");
    },
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const filteredConversations = conversations.filter(conversation => {
    if (!searchTerm) return true;
    
    const participantNames = conversation.participants
      .filter(p => p.id !== user?.id)
      .map(p => `${p.firstName} ${p.lastName}`)
      .join(" ");
    
    return participantNames.toLowerCase().includes(searchTerm.toLowerCase()) ||
           conversation.name?.toLowerCase().includes(searchTerm.toLowerCase());
  });

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !selectedConversation) return;

    sendMessageMutation.mutate({
      conversationId: selectedConversation,
      content: newMessage,
    });
  };

  const getConversationName = (conversation: Conversation) => {
    if (conversation.type === "group") {
      return conversation.name || "Group Chat";
    }
    
    const otherParticipant = conversation.participants.find(p => p.id !== user?.id);
    return otherParticipant ? `${otherParticipant.firstName} ${otherParticipant.lastName}` : "Unknown";
  };

  const getConversationAvatar = (conversation: Conversation) => {
    if (conversation.type === "group") {
      return undefined; // Could show group avatar
    }
    
    const otherParticipant = conversation.participants.find(p => p.id !== user?.id);
    return otherParticipant?.profilePicture;
  };

  const selectedConversationData = conversations.find(c => c.id === selectedConversation);

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold">Messages</h1>
          <p className="text-gray-600 mt-2">Connect with your professional network</p>
        </div>
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          New Message
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[600px]">
        {/* Conversations List */}
        <Card className="lg:col-span-1">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle>Conversations</CardTitle>
              <Button size="sm" variant="ghost">
                <MoreHorizontal className="w-4 h-4" />
              </Button>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search conversations..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="h-[480px]">
              {filteredConversations.map((conversation, index) => (
                <div key={conversation.id}>
                  <div
                    className={`p-4 cursor-pointer hover:bg-gray-50 transition-colors ${
                      selectedConversation === conversation.id ? "bg-blue-50 border-r-2 border-blue-500" : ""
                    }`}
                    onClick={() => setSelectedConversation(conversation.id)}
                  >
                    <div className="flex items-start gap-3">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={getConversationAvatar(conversation)} />
                        <AvatarFallback>
                          {getConversationName(conversation).split(" ").map(n => n[0]).join("")}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium text-sm truncate">
                            {getConversationName(conversation)}
                          </h4>
                          {conversation.unreadCount > 0 && (
                            <Badge variant="default" className="ml-2 px-2 py-0 text-xs">
                              {conversation.unreadCount}
                            </Badge>
                          )}
                        </div>
                        {conversation.lastMessage && (
                          <div className="mt-1">
                            <p className="text-xs text-gray-600 truncate">
                              {conversation.lastMessage.content}
                            </p>
                            <p className="text-xs text-gray-400 mt-1">
                              {format(new Date(conversation.lastMessage.createdAt), "MMM dd, h:mm a")}
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  {index < filteredConversations.length - 1 && <Separator />}
                </div>
              ))}
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Chat Area */}
        <Card className="lg:col-span-2">
          {selectedConversationData ? (
            <div className="flex flex-col h-full">
              {/* Chat Header */}
              <CardHeader className="pb-3 border-b">
                <div className="flex items-center gap-3">
                  <Avatar className="w-10 h-10">
                    <AvatarImage src={getConversationAvatar(selectedConversationData)} />
                    <AvatarFallback>
                      {getConversationName(selectedConversationData).split(" ").map(n => n[0]).join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <h3 className="font-semibold">
                      {getConversationName(selectedConversationData)}
                    </h3>
                    {selectedConversationData.type === "direct" && (
                      <p className="text-sm text-gray-500">
                        {selectedConversationData.participants.find(p => p.id !== user?.id)?.headline}
                      </p>
                    )}
                  </div>
                  <Button size="sm" variant="ghost">
                    <MoreHorizontal className="w-4 h-4" />
                  </Button>
                </div>
              </CardHeader>

              {/* Messages */}
              <CardContent className="flex-1 p-0">
                <ScrollArea className="h-[400px] p-4">
                  <div className="space-y-4">
                    {messages.map((message) => (
                      <div
                        key={message.id}
                        className={`flex ${message.senderId === user?.id ? "justify-end" : "justify-start"}`}
                      >
                        <div className={`flex gap-2 max-w-[70%] ${message.senderId === user?.id ? "flex-row-reverse" : ""}`}>
                          {message.senderId !== user?.id && (
                            <Avatar className="w-8 h-8">
                              <AvatarImage src={message.sender.profilePicture} />
                              <AvatarFallback className="text-xs">
                                {message.sender.firstName[0]}{message.sender.lastName[0]}
                              </AvatarFallback>
                            </Avatar>
                          )}
                          <div
                            className={`p-3 rounded-lg ${
                              message.senderId === user?.id
                                ? "bg-blue-500 text-white"
                                : "bg-gray-100 text-gray-900"
                            }`}
                          >
                            <p className="text-sm">{message.content}</p>
                            <p className={`text-xs mt-1 ${
                              message.senderId === user?.id ? "text-blue-100" : "text-gray-500"
                            }`}>
                              {format(new Date(message.createdAt), "h:mm a")}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                    <div ref={messagesEndRef} />
                  </div>
                </ScrollArea>
              </CardContent>

              {/* Message Input */}
              <div className="p-4 border-t">
                <form onSubmit={handleSendMessage} className="flex items-center gap-2">
                  <Button size="sm" variant="ghost" type="button">
                    <Paperclip className="w-4 h-4" />
                  </Button>
                  <Input
                    placeholder="Type a message..."
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    className="flex-1"
                  />
                  <Button size="sm" variant="ghost" type="button">
                    <Smile className="w-4 h-4" />
                  </Button>
                  <Button size="sm" type="submit" disabled={!newMessage.trim() || sendMessageMutation.isPending}>
                    <Send className="w-4 h-4" />
                  </Button>
                </form>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center h-full">
              <div className="text-center">
                <div className="w-16 h-16 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
                  <Send className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Select a conversation</h3>
                <p className="text-gray-600">Choose a conversation to start messaging</p>
              </div>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}