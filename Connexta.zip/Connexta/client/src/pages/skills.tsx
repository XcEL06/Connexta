import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Plus, Search, Award, TrendingUp } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { authService } from "@/lib/auth";

interface Skill {
  id: number;
  name: string;
  category: string;
  level: string;
  yearsOfExperience: number;
  endorsements: number;
}

export default function SkillsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const queryClient = useQueryClient();
  const user = authService.getState().user;

  const { data: skills = [] } = useQuery<Skill[]>({
    queryKey: ["/api/skills", user?.id],
    enabled: !!user,
  });

  const { data: availableSkills = [] } = useQuery<Skill[]>({
    queryKey: ["/api/skills/available"],
  });

  const addSkillMutation = useMutation({
    mutationFn: (skillData: { skillId: number; level: string; yearsOfExperience: number }) =>
      apiRequest("/api/skills/add", "POST", skillData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/skills"] });
    },
  });

  const categories = ["all", "Technical", "Soft Skills", "Languages", "Industry Knowledge"];

  const filteredSkills = skills.filter(skill => {
    const matchesSearch = skill.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "all" || skill.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Skills & Endorsements</h1>
          <p className="text-gray-600 mt-2">Showcase your professional skills and get endorsed by colleagues</p>
        </div>
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          Add Skill
        </Button>
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search skills..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <div className="flex gap-2">
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(category)}
            >
              {category}
            </Button>
          ))}
        </div>
      </div>

      {/* Skills Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredSkills.map((skill) => (
          <Card key={skill.id} className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{skill.name}</CardTitle>
                <Badge variant="secondary">{skill.category}</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Level:</span>
                <Badge variant={skill.level === "expert" ? "default" : "outline"}>
                  {skill.level}
                </Badge>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Experience:</span>
                <span className="text-sm font-medium">{skill.yearsOfExperience} years</span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Endorsements:</span>
                <div className="flex items-center gap-1">
                  <Award className="w-4 h-4 text-yellow-500" />
                  <span className="text-sm font-medium">{skill.endorsements}</span>
                </div>
              </div>

              <div className="pt-2">
                <Button size="sm" variant="outline" className="w-full">
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Get Endorsement
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredSkills.length === 0 && (
        <div className="text-center py-12">
          <div className="w-24 h-24 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
            <Award className="w-12 h-12 text-gray-400" />
          </div>
          <h3 className="text-lg font-semibold mb-2">No skills found</h3>
          <p className="text-gray-600 mb-4">Add your first skill to showcase your expertise</p>
          <Button>
            <Plus className="w-4 h-4 mr-2" />
            Add Your First Skill
          </Button>
        </div>
      )}
    </div>
  );
}