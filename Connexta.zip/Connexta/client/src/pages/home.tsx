import Header from "@/components/header";
import LeftSidebar from "@/components/left-sidebar";
import MainFeed from "@/components/main-feed";
import RightSidebar from "@/components/right-sidebar";

export default function Home() {
  return (
    <div className="min-h-screen bg-[var(--connexta-gray)]">
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-3">
            <LeftSidebar />
          </div>
          <div className="lg:col-span-6">
            <MainFeed />
          </div>
          <div className="lg:col-span-3">
            <RightSidebar />
          </div>
        </div>
      </main>
    </div>
  );
}
