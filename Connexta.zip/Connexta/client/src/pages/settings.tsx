import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { authService } from "@/lib/auth";
import { Separator } from "@/components/ui/separator";
import { 
  User, 
  Shield, 
  Eye, 
  Lock, 
  Bell, 
  Ban,
  Save
} from "lucide-react";

const SETTINGS_SECTIONS = [
  { id: 'Account', label: 'Account', icon: User },
  { id: 'Security', label: 'Security', icon: Shield },
  { id: 'Visibility', label: 'Visibility', icon: Eye },
  { id: 'Privacy', label: 'Privacy', icon: Lock },
  { id: 'Notifications', label: 'Notifications', icon: Bell },
  { id: 'Blocking', label: 'Blocking', icon: Ban }
];

interface SettingsState {
  Account?: {
    firstName?: string;
    lastName?: string;
    email?: string;
    headline?: string;
    location?: string;
  };
  Security?: {
    twoFactorEnabled?: boolean;
    loginNotifications?: boolean;
  };
  Visibility?: {
    profileVisibility?: string;
    searchIndexing?: boolean;
    showConnections?: boolean;
    showActivity?: boolean;
  };
  Privacy?: {
    allowMessages?: string;
    allowConnectionRequests?: string;
    showEmail?: boolean;
    showLocation?: boolean;
  };
  Notifications?: {
    emailNotifications?: boolean;
    connectionRequests?: boolean;
    messages?: boolean;
    jobAlerts?: boolean;
    networkUpdates?: boolean;
  };
  Blocking?: {
    blockedUsers?: string[];
  };
}

export default function Settings() {
  const [active, setActive] = useState('Account');
  const [settings, setSettings] = useState<SettingsState>({});
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const user = authService.getState().user;

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await fetch('/api/settings/user', {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
        
        if (response.ok) {
          const data = await response.json();
          setSettings(data);
        } else {
          // Initialize with default settings
          setSettings({
            Account: {
              firstName: user?.firstName || '',
              lastName: user?.lastName || '',
              email: user?.email || '',
              headline: user?.headline || '',
              location: user?.location || '',
            },
            Visibility: {
              profileVisibility: 'Public',
              searchIndexing: true,
              showConnections: true,
              showActivity: true,
            },
            Privacy: {
              allowMessages: 'Everyone',
              allowConnectionRequests: 'Everyone',
              showEmail: false,
              showLocation: true,
            },
            Notifications: {
              emailNotifications: true,
              connectionRequests: true,
              messages: true,
              jobAlerts: false,
              networkUpdates: true,
            },
            Security: {
              twoFactorEnabled: false,
              loginNotifications: true,
            },
          });
        }
      } catch (error) {
        console.error('Failed to fetch settings:', error);
      }
    };

    fetchSettings();
  }, [user]);

  const handleToggle = async (section: string, key: string, value: any) => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/settings/update', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ section, key, value }),
      });

      if (response.ok) {
        setSettings(prev => ({
          ...prev,
          [section]: { ...prev[section], [key]: value }
        }));
        
        toast({
          title: "Settings updated",
          description: "Your changes have been saved successfully.",
        });
      } else {
        throw new Error('Failed to update settings');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update settings. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const ActiveIcon = SETTINGS_SECTIONS.find(s => s.id === active)?.icon || User;

  return (
    <div className="container mx-auto py-6">
      <div className="flex gap-6">
        {/* Sidebar Navigation */}
        <Card className="w-64 h-fit">
          <CardHeader>
            <CardTitle className="text-lg">Settings</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <nav className="space-y-1">
              {SETTINGS_SECTIONS.map((section) => {
                const Icon = section.icon;
                return (
                  <button
                    key={section.id}
                    onClick={() => setActive(section.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 text-left transition-colors hover:bg-gray-100 ${
                      active === section.id 
                        ? 'bg-connexta-blue text-white hover:bg-connexta-navy' 
                        : 'text-gray-700'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {section.label}
                  </button>
                );
              })}
            </nav>
          </CardContent>
        </Card>

        {/* Settings Content */}
        <div className="flex-1">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ActiveIcon className="w-5 h-5" />
                {active} Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              
              {/* Account Settings */}
              {active === 'Account' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="firstName">First Name</Label>
                      <Input
                        id="firstName"
                        value={settings.Account?.firstName || ''}
                        onChange={(e) => handleToggle('Account', 'firstName', e.target.value)}
                        disabled={loading}
                      />
                    </div>
                    <div>
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input
                        id="lastName"
                        value={settings.Account?.lastName || ''}
                        onChange={(e) => handleToggle('Account', 'lastName', e.target.value)}
                        disabled={loading}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={settings.Account?.email || ''}
                      onChange={(e) => handleToggle('Account', 'email', e.target.value)}
                      disabled={loading}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="headline">Professional Headline</Label>
                    <Input
                      id="headline"
                      value={settings.Account?.headline || ''}
                      onChange={(e) => handleToggle('Account', 'headline', e.target.value)}
                      disabled={loading}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="location">Location</Label>
                    <Input
                      id="location"
                      value={settings.Account?.location || ''}
                      onChange={(e) => handleToggle('Account', 'location', e.target.value)}
                      disabled={loading}
                    />
                  </div>
                </div>
              )}

              {/* Visibility Settings */}
              {active === 'Visibility' && (
                <div className="space-y-6">
                  <div>
                    <Label htmlFor="profileVisibility">Profile Visibility</Label>
                    <Select
                      value={settings.Visibility?.profileVisibility || 'Public'}
                      onValueChange={(value) => handleToggle('Visibility', 'profileVisibility', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Public">Public</SelectItem>
                        <SelectItem value="Connections">Connections Only</SelectItem>
                        <SelectItem value="Private">Private</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Allow Search Indexing</Label>
                      <p className="text-sm text-gray-500">
                        Let search engines index your profile
                      </p>
                    </div>
                    <Switch
                      checked={settings.Visibility?.searchIndexing || false}
                      onCheckedChange={(checked) => handleToggle('Visibility', 'searchIndexing', checked)}
                      disabled={loading}
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Show Connections</Label>
                      <p className="text-sm text-gray-500">
                        Display your connections on your profile
                      </p>
                    </div>
                    <Switch
                      checked={settings.Visibility?.showConnections || false}
                      onCheckedChange={(checked) => handleToggle('Visibility', 'showConnections', checked)}
                      disabled={loading}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Show Activity</Label>
                      <p className="text-sm text-gray-500">
                        Show your recent activity and posts
                      </p>
                    </div>
                    <Switch
                      checked={settings.Visibility?.showActivity || false}
                      onCheckedChange={(checked) => handleToggle('Visibility', 'showActivity', checked)}
                      disabled={loading}
                    />
                  </div>
                </div>
              )}

              {/* Privacy Settings */}
              {active === 'Privacy' && (
                <div className="space-y-6">
                  <div>
                    <Label>Who can send you messages?</Label>
                    <Select
                      value={settings.Privacy?.allowMessages || 'Everyone'}
                      onValueChange={(value) => handleToggle('Privacy', 'allowMessages', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Everyone">Everyone</SelectItem>
                        <SelectItem value="Connections">Connections Only</SelectItem>
                        <SelectItem value="Nobody">Nobody</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Who can send connection requests?</Label>
                    <Select
                      value={settings.Privacy?.allowConnectionRequests || 'Everyone'}
                      onValueChange={(value) => handleToggle('Privacy', 'allowConnectionRequests', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Everyone">Everyone</SelectItem>
                        <SelectItem value="SecondDegree">2nd Degree Connections</SelectItem>
                        <SelectItem value="Nobody">Nobody</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Show Email Address</Label>
                      <p className="text-sm text-gray-500">
                        Display your email on your profile
                      </p>
                    </div>
                    <Switch
                      checked={settings.Privacy?.showEmail || false}
                      onCheckedChange={(checked) => handleToggle('Privacy', 'showEmail', checked)}
                      disabled={loading}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Show Location</Label>
                      <p className="text-sm text-gray-500">
                        Display your location on your profile
                      </p>
                    </div>
                    <Switch
                      checked={settings.Privacy?.showLocation || false}
                      onCheckedChange={(checked) => handleToggle('Privacy', 'showLocation', checked)}
                      disabled={loading}
                    />
                  </div>
                </div>
              )}

              {/* Notifications Settings */}
              {active === 'Notifications' && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Email Notifications</Label>
                      <p className="text-sm text-gray-500">
                        Receive notifications via email
                      </p>
                    </div>
                    <Switch
                      checked={settings.Notifications?.emailNotifications || false}
                      onCheckedChange={(checked) => handleToggle('Notifications', 'emailNotifications', checked)}
                      disabled={loading}
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Connection Requests</Label>
                      <p className="text-sm text-gray-500">
                        Notify when someone wants to connect
                      </p>
                    </div>
                    <Switch
                      checked={settings.Notifications?.connectionRequests || false}
                      onCheckedChange={(checked) => handleToggle('Notifications', 'connectionRequests', checked)}
                      disabled={loading}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Messages</Label>
                      <p className="text-sm text-gray-500">
                        Notify when you receive messages
                      </p>
                    </div>
                    <Switch
                      checked={settings.Notifications?.messages || false}
                      onCheckedChange={(checked) => handleToggle('Notifications', 'messages', checked)}
                      disabled={loading}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Job Alerts</Label>
                      <p className="text-sm text-gray-500">
                        Notify about relevant job opportunities
                      </p>
                    </div>
                    <Switch
                      checked={settings.Notifications?.jobAlerts || false}
                      onCheckedChange={(checked) => handleToggle('Notifications', 'jobAlerts', checked)}
                      disabled={loading}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Network Updates</Label>
                      <p className="text-sm text-gray-500">
                        Notify about your network's activity
                      </p>
                    </div>
                    <Switch
                      checked={settings.Notifications?.networkUpdates || false}
                      onCheckedChange={(checked) => handleToggle('Notifications', 'networkUpdates', checked)}
                      disabled={loading}
                    />
                  </div>
                </div>
              )}

              {/* Security Settings */}
              {active === 'Security' && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Two-Factor Authentication</Label>
                      <p className="text-sm text-gray-500">
                        Add an extra layer of security to your account
                      </p>
                    </div>
                    <Switch
                      checked={settings.Security?.twoFactorEnabled || false}
                      onCheckedChange={(checked) => handleToggle('Security', 'twoFactorEnabled', checked)}
                      disabled={loading}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Login Notifications</Label>
                      <p className="text-sm text-gray-500">
                        Get notified of new sign-ins to your account
                      </p>
                    </div>
                    <Switch
                      checked={settings.Security?.loginNotifications || false}
                      onCheckedChange={(checked) => handleToggle('Security', 'loginNotifications', checked)}
                      disabled={loading}
                    />
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <Button variant="outline" className="w-full">
                      Change Password
                    </Button>
                    <Button variant="outline" className="w-full">
                      Download Account Data
                    </Button>
                    <Button variant="destructive" className="w-full">
                      Delete Account
                    </Button>
                  </div>
                </div>
              )}

              {/* Blocking Settings */}
              {active === 'Blocking' && (
                <div className="space-y-6">
                  <div>
                    <Label htmlFor="blockUser">Block a User</Label>
                    <div className="flex gap-2 mt-2">
                      <Input
                        id="blockUser"
                        placeholder="Enter username or email"
                        disabled={loading}
                      />
                      <Button disabled={loading}>
                        Block
                      </Button>
                    </div>
                  </div>

                  <Separator />

                  <div>
                    <Label>Blocked Users</Label>
                    <div className="mt-2 space-y-2">
                      {settings.Blocking?.blockedUsers?.length ? (
                        settings.Blocking.blockedUsers.map((user, index) => (
                          <div key={index} className="flex items-center justify-between p-3 border rounded">
                            <span>{user}</span>
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => {
                                const updatedList = settings.Blocking?.blockedUsers?.filter((_, i) => i !== index) || [];
                                handleToggle('Blocking', 'blockedUsers', updatedList);
                              }}
                            >
                              Unblock
                            </Button>
                          </div>
                        ))
                      ) : (
                        <p className="text-gray-500 text-sm">No blocked users</p>
                      )}
                    </div>
                  </div>
                </div>
              )}

            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}