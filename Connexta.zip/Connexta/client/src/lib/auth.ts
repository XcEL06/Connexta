import { User } from "@shared/schema";

const TOKEN_KEY = "connexta_token";
const USER_KEY = "connexta_user";

export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
}

export class AuthService {
  private static instance: AuthService;
  private authState: AuthState = {
    user: null,
    token: null,
    isAuthenticated: false,
  };
  private listeners: ((state: AuthState) => void)[] = [];

  private constructor() {
    this.loadFromStorage();
  }

  static getInstance(): AuthService {
    if (!AuthService.instance) {
      AuthService.instance = new AuthService();
    }
    return AuthService.instance;
  }

  private loadFromStorage() {
    try {
      const token = localStorage.getItem(TOKEN_KEY);
      const userStr = localStorage.getItem(USER_KEY);
      
      if (token && userStr) {
        const user = JSON.parse(userStr);
        this.authState = {
          user,
          token,
          isAuthenticated: true,
        };
      }
    } catch (error) {
      console.error("Error loading auth from storage:", error);
      this.clearStorage();
    }
  }

  private saveToStorage() {
    if (this.authState.token && this.authState.user) {
      localStorage.setItem(TOKEN_KEY, this.authState.token);
      localStorage.setItem(USER_KEY, JSON.stringify(this.authState.user));
    } else {
      this.clearStorage();
    }
  }

  private clearStorage() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
  }

  private notify() {
    this.listeners.forEach(listener => listener(this.authState));
  }

  subscribe(listener: (state: AuthState) => void) {
    this.listeners.push(listener);
    return () => {
      const index = this.listeners.indexOf(listener);
      if (index > -1) {
        this.listeners.splice(index, 1);
      }
    };
  }

  getState(): AuthState {
    return { ...this.authState };
  }

  setAuth(user: User, token: string) {
    this.authState = {
      user,
      token,
      isAuthenticated: true,
    };
    this.saveToStorage();
    this.notify();
  }

  logout() {
    this.authState = {
      user: null,
      token: null,
      isAuthenticated: false,
    };
    this.clearStorage();
    this.notify();
  }

  getAuthHeaders() {
    return this.authState.token
      ? { Authorization: `Bearer ${this.authState.token}` }
      : {};
  }
}

export const authService = AuthService.getInstance();
