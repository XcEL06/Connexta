# Connexta - Professional Social Network

## Overview

Connexta is a professional social networking platform similar to LinkedIn, built with a modern full-stack architecture. The application enables users to create profiles, share posts, connect with other professionals, apply for jobs, and manage their professional network. It features a comprehensive user authentication system, real-time interactions, file uploads for profile pictures and posts, and a responsive design optimized for both desktop and mobile devices.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Libraries:**
- React 18 with TypeScript for type-safe component development
- Vite as the build tool and development server for fast hot-reloading
- Wouter for lightweight client-side routing
- TanStack Query for server state management and caching
- Tailwind CSS for utility-first styling with custom design system

**Component Structure:**
- Radix UI primitives for accessible, unstyled components
- shadcn/ui component library for consistent design patterns
- Custom components organized by feature (authentication, posts, profiles, connections)
- Responsive grid layout using CSS Grid for main application structure

**State Management:**
- Custom AuthService singleton for authentication state
- TanStack Query for server state with automatic caching and invalidation
- Local component state for UI interactions

### Backend Architecture

**Server Framework:**
- Express.js with TypeScript for API development
- RESTful API design with structured routing
- Custom middleware for request logging and error handling
- JWT-based authentication with bcrypt password hashing

**Database Layer:**
- PostgreSQL as the primary database via Neon Database
- Drizzle ORM for type-safe database operations and migrations
- Connection pooling for optimal database performance
- Shared schema definitions between frontend and backend

**File Upload System:**
- Cloudinary integration for image storage and optimization
- Multer middleware for handling multipart form data
- Automatic image optimization with different transformations for profiles vs. posts
- Support for profile pictures, cover photos, and post images

### Data Storage Solutions

**Database Schema:**
- Users table with comprehensive profile information
- Posts table with author relationships and engagement metrics
- Jobs table for job postings with recruiter information
- Connections table for managing friend requests and professional relationships
- Additional tables for likes, follows, and user settings

**File Storage:**
- Cloudinary for all image assets with automatic format optimization
- Organized folder structure (profiles, posts, covers)
- Image transformations for different use cases (thumbnails, full-size)

### Authentication and Authorization

**Authentication Flow:**
- JWT tokens for stateless authentication
- Secure password hashing with bcrypt
- Token-based API authorization middleware
- Client-side auth state management with localStorage persistence

**Security Features:**
- Protected routes requiring authentication
- Input validation using Zod schemas
- Secure API endpoints with proper error handling
- CORS configuration for cross-origin requests

## External Dependencies

### Database Services
- **Neon Database**: Serverless PostgreSQL database hosting
- **Drizzle Kit**: Database migration management and schema synchronization

### Third-Party Services
- **Cloudinary**: Image storage, optimization, and delivery CDN
  - Automatic format selection and quality optimization
  - Image transformations for different display contexts
  - Organized asset management with folder structures

### Development Tools
- **Vite**: Frontend build tool with development server
- **ESBuild**: Fast JavaScript bundler for production builds
- **PostCSS**: CSS processing with Tailwind CSS integration
- **TypeScript**: Static type checking across the entire application

### UI/UX Libraries
- **Radix UI**: Accessible component primitives
- **Lucide React**: Icon library for consistent iconography
- **Date-fns**: Date formatting and manipulation
- **Class Variance Authority**: Utility for component variant management

### Authentication & Security
- **bcrypt**: Password hashing for secure authentication
- **jsonwebtoken**: JWT token generation and verification
- **connect-pg-simple**: PostgreSQL session store (if session-based auth is implemented)

### Development and Deployment
- **tsx**: TypeScript execution for development
- **Replit Integration**: Development environment optimization with runtime error handling
- Environment variable management for API keys and database connections