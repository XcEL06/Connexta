import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, loginSchema, insertPostSchema, insertJobSchema, insertConnectionSchema } from "@shared/schema";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { upload, uploadProfile, uploadCover } from "./upload";

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";

interface AuthRequest extends Request {
  userId?: number;
}

// Middleware to verify JWT token
const authenticateToken = (req: AuthRequest, res: Response, next: Function) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err: any, decoded: any) => {
    if (err) {
      return res.status(403).json({ message: 'Invalid or expired token' });
    }
    req.userId = decoded.userId;
    next();
  });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post("/api/auth/register", async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists with this email" });
      }

      const existingUsername = await storage.getUserByUsername(userData.username);
      if (existingUsername) {
        return res.status(400).json({ message: "Username already taken" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(userData.password, 10);
      
      // Create user
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword,
      });

      // Generate JWT token
      const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '7d' });

      // Return user without password
      const { password, ...userWithoutPassword } = user;
      res.status(201).json({ user: userWithoutPassword, token });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(400).json({ message: "Invalid user data" });
    }
  });

  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { email, password } = loginSchema.parse(req.body);
      
      // Find user
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Verify password
      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Generate JWT token
      const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '7d' });

      // Return user without password
      const { password: _, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword, token });
    } catch (error) {
      console.error("Login error:", error);
      res.status(400).json({ message: "Invalid login data" });
    }
  });

  app.get("/api/auth/me", authenticateToken, async (req: AuthRequest, res: Response) => {
    try {
      const user = await storage.getUser(req.userId!);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Get user error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Posts routes
  app.get("/api/posts", authenticateToken, async (req: AuthRequest, res: Response) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const offset = parseInt(req.query.offset as string) || 0;
      
      const posts = await storage.getPosts(limit, offset);
      res.json(posts);
    } catch (error) {
      console.error("Get posts error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/posts", authenticateToken, async (req: AuthRequest, res: Response) => {
    try {
      const postData = insertPostSchema.parse({
        ...req.body,
        authorId: req.userId,
      });
      
      const post = await storage.createPost(postData);
      const postWithAuthor = await storage.getPost(post.id);
      
      res.status(201).json(postWithAuthor);
    } catch (error) {
      console.error("Create post error:", error);
      res.status(400).json({ message: "Invalid post data" });
    }
  });

  app.post("/api/posts/:id/like", authenticateToken, async (req: AuthRequest, res: Response) => {
    try {
      const postId = parseInt(req.params.id);
      const isLiked = await storage.togglePostLike(postId, req.userId!);
      
      res.json({ liked: isLiked });
    } catch (error) {
      console.error("Toggle like error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/posts/:id/liked", authenticateToken, async (req: AuthRequest, res: Response) => {
    try {
      const postId = parseInt(req.params.id);
      const isLiked = await storage.isPostLiked(postId, req.userId!);
      
      res.json({ liked: isLiked });
    } catch (error) {
      console.error("Check like error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Jobs routes
  app.get("/api/jobs", authenticateToken, async (req: AuthRequest, res: Response) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const jobs = await storage.getJobs(limit);
      res.json(jobs);
    } catch (error) {
      console.error("Get jobs error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/jobs", authenticateToken, async (req: AuthRequest, res: Response) => {
    try {
      const jobData = insertJobSchema.parse(req.body);
      const job = await storage.createJob(jobData);
      res.status(201).json(job);
    } catch (error) {
      console.error("Create job error:", error);
      res.status(400).json({ message: "Invalid job data" });
    }
  });

  // Connections routes
  app.get("/api/connections", authenticateToken, async (req: AuthRequest, res: Response) => {
    try {
      const connections = await storage.getConnections(req.userId!);
      res.json(connections);
    } catch (error) {
      console.error("Get connections error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/connections", authenticateToken, async (req: AuthRequest, res: Response) => {
    try {
      const connectionData = insertConnectionSchema.parse({
        ...req.body,
        requesterId: req.userId,
      });
      
      const connection = await storage.createConnection(connectionData);
      res.status(201).json(connection);
    } catch (error) {
      console.error("Create connection error:", error);
      if (error.message === "Connection request already exists") {
        res.status(409).json({ message: error.message });
      } else {
        res.status(400).json({ message: "Invalid connection data" });
      }
    }
  });

  // Get pending connection requests (received)
  app.get("/api/connections/pending", authenticateToken, async (req: AuthRequest, res: Response) => {
    try {
      const pendingRequests = await storage.getPendingConnectionRequests(req.userId!);
      res.json(pendingRequests);
    } catch (error) {
      console.error("Get pending requests error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get sent connection requests
  app.get("/api/connections/sent", authenticateToken, async (req: AuthRequest, res: Response) => {
    try {
      const sentRequests = await storage.getSentConnectionRequests(req.userId!);
      res.json(sentRequests);
    } catch (error) {
      console.error("Get sent requests error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Accept or reject connection request
  app.patch("/api/connections/:id", authenticateToken, async (req: AuthRequest, res: Response) => {
    try {
      const connectionId = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!["accepted", "rejected"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }

      const connection = await storage.updateConnectionStatus(connectionId, status);
      if (!connection) {
        return res.status(404).json({ message: "Connection request not found" });
      }

      res.json(connection);
    } catch (error) {
      console.error("Update connection status error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Friend management routes (compatible with existing connection system)
  app.post("/api/friends/addfriend", authenticateToken, async (req: AuthRequest, res: Response) => {
    try {
      const { requesterId, recipientId } = req.body;
      
      // Use the requesterId from the body if provided, otherwise use the authenticated user ID
      const actualRequesterId = requesterId || req.userId!;
      
      const connectionData = { requesterId: actualRequesterId, recipientId };
      await storage.createConnection(connectionData);
      
      res.status(200).json({ message: "Friend request sent!" });
    } catch (error) {
      console.error("Add friend error:", error);
      if (error.message === "Connection request already exists") {
        res.status(409).json({ error: "Friend request already exists" });
      } else {
        res.status(500).json({ error: "Error sending friend request" });
      }
    }
  });

  app.post("/api/friends/acceptfriend", authenticateToken, async (req: AuthRequest, res: Response) => {
    try {
      const { requesterId } = req.body;
      const recipientId = req.userId!;
      
      // Find the connection request
      const pendingRequests = await storage.getPendingConnectionRequests(recipientId);
      const request = pendingRequests.find(r => r.requesterId === requesterId);
      
      if (!request) {
        return res.status(404).json({ error: "Friend request not found" });
      }
      
      await storage.updateConnectionStatus(request.id, "accepted");
      res.status(200).json({ message: "Friend request accepted!" });
    } catch (error) {
      console.error("Accept friend error:", error);
      res.status(500).json({ error: "Error accepting friend request" });
    }
  });

  app.post("/api/friends/rejectfriend", authenticateToken, async (req: AuthRequest, res: Response) => {
    try {
      const { requesterId } = req.body;
      const recipientId = req.userId!;
      
      // Find the connection request
      const pendingRequests = await storage.getPendingConnectionRequests(recipientId);
      const request = pendingRequests.find(r => r.requesterId === requesterId);
      
      if (!request) {
        return res.status(404).json({ error: "Friend request not found" });
      }
      
      await storage.updateConnectionStatus(request.id, "rejected");
      res.status(200).json({ message: "Friend request rejected!" });
    } catch (error) {
      console.error("Reject friend error:", error);
      res.status(500).json({ error: "Error rejecting friend request" });
    }
  });

  // Follow routes (matching React component structure)
  app.post("/api/follow/follow", authenticateToken, async (req: AuthRequest, res: Response) => {
    try {
      const { followerId, followingId } = req.body;
      
      // Use followerId from body if provided, otherwise use authenticated user
      const actualFollowerId = followerId || req.userId!;

      const follow = await storage.followUser(actualFollowerId, followingId);
      res.status(200).json({ message: "Followed successfully!" });
    } catch (error) {
      console.error("Follow user error:", error);
      if (error.message === "Already following this user") {
        res.status(409).json({ error: error.message });
      } else if (error.message === "Cannot follow yourself") {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Error following user" });
      }
    }
  });

  app.post("/api/follow/unfollow", authenticateToken, async (req: AuthRequest, res: Response) => {
    try {
      const { followerId, followingId } = req.body;
      
      // Use followerId from body if provided, otherwise use authenticated user
      const actualFollowerId = followerId || req.userId!;

      const success = await storage.unfollowUser(actualFollowerId, followingId);
      if (success) {
        res.status(200).json({ message: "Unfollowed successfully!" });
      } else {
        res.status(404).json({ error: "Follow relationship not found" });
      }
    } catch (error) {
      console.error("Unfollow user error:", error);
      res.status(500).json({ error: "Error unfollowing user" });
    }
  });

  app.get("/api/follow/check", authenticateToken, async (req: AuthRequest, res: Response) => {
    try {
      const followerId = parseInt(req.query.followerId as string);
      const followingId = parseInt(req.query.followingId as string);

      const isFollowing = await storage.isFollowing(followerId, followingId);
      res.json({ isFollowing });
    } catch (error) {
      console.error("Check follow status error:", error);
      res.status(500).json({ error: "Error checking follow status" });
    }
  });

  app.get("/api/followers/:userId", authenticateToken, async (req: AuthRequest, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const followers = await storage.getFollowers(userId);
      res.json(followers);
    } catch (error) {
      console.error("Get followers error:", error);
      res.status(500).json({ error: "Error getting followers" });
    }
  });

  app.get("/api/following/:userId", authenticateToken, async (req: AuthRequest, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const following = await storage.getFollowing(userId);
      res.json(following);
    } catch (error) {
      console.error("Get following error:", error);
      res.status(500).json({ error: "Error getting following list" });
    }
  });

  app.get("/api/follow/stats/:userId", authenticateToken, async (req: AuthRequest, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const stats = await storage.getFollowStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Get follow stats error:", error);
      res.status(500).json({ error: "Error getting follow stats" });
    }
  });

  // Image upload routes
  app.post("/api/upload/profile", authenticateToken, uploadProfile.single('profile'), async (req: AuthRequest, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const imageUrl = (req.file as any).path;
      const userId = req.userId!;

      // Update user's profile picture and avatar in database
      await storage.updateUser(userId, { 
        profilePicture: imageUrl,
        avatar: imageUrl 
      });

      res.json({ 
        message: "Profile picture uploaded successfully",
        imageUrl: imageUrl 
      });
    } catch (error) {
      console.error("Profile upload error:", error);
      res.status(500).json({ error: "Error uploading profile picture" });
    }
  });

  app.post("/api/upload/profilepic/:userId", authenticateToken, uploadProfile.single('image'), async (req: AuthRequest, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const imageUrl = (req.file as any).path;
      const userId = parseInt(req.params.userId);

      // Verify user can only update their own profile
      if (userId !== req.userId) {
        return res.status(403).json({ error: "Unauthorized" });
      }

      // Update user's profile picture and avatar in database
      await storage.updateUser(userId, { 
        profilePicture: imageUrl,
        avatar: imageUrl 
      });

      res.json({ 
        message: "Profile picture updated!",
        imageUrl: imageUrl 
      });
    } catch (error) {
      console.error("Profile upload error:", error);
      res.status(500).json({ error: "Upload failed" });
    }
  });

  app.post("/api/upload/cover", authenticateToken, uploadCover.single('cover'), async (req: AuthRequest, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const imageUrl = (req.file as any).path;
      const userId = req.userId!;

      // Update user's cover picture and coverPhoto in database
      await storage.updateUser(userId, { 
        coverPicture: imageUrl,
        coverPhoto: imageUrl 
      });

      res.json({ 
        message: "Cover photo uploaded successfully",
        imageUrl: imageUrl 
      });
    } catch (error) {
      console.error("Cover upload error:", error);
      res.status(500).json({ error: "Error uploading cover photo" });
    }
  });

  app.post("/api/upload/post", authenticateToken, upload.single('image'), async (req: AuthRequest, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const imageUrl = (req.file as any).path;

      res.json({ 
        message: "Image uploaded successfully",
        imageUrl: imageUrl 
      });
    } catch (error) {
      console.error("Post image upload error:", error);
      res.status(500).json({ error: "Error uploading image" });
    }
  });

  // Suggestions routes
  app.get("/api/suggestions/users", authenticateToken, async (req: AuthRequest, res: Response) => {
    try {
      const limit = parseInt(req.query.limit as string) || 5;
      const users = await storage.getSuggestedUsers(req.userId!, limit);
      res.json(users);
    } catch (error) {
      console.error("Get suggested users error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Settings routes
  app.get("/api/settings/user", authenticateToken, async (req: AuthRequest, res: Response) => {
    try {
      const userId = req.userId!;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      // Get settings from database or return defaults
      const settings = await storage.getUserSettings(userId);
      
      // Merge account info with settings
      settings.Account = {
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        headline: user.headline,
        location: user.location,
        ...settings.Account
      };

      res.json(settings);
    } catch (error) {
      console.error("Error getting user settings:", error);
      res.status(500).json({ error: "Error getting user settings" });
    }
  });

  app.post("/api/settings/update", authenticateToken, async (req: AuthRequest, res: Response) => {
    try {
      const userId = req.userId!;
      const { section, key, value } = req.body;

      if (!section || !key) {
        return res.status(400).json({ error: "Section and key are required" });
      }

      // Handle Account section updates by updating user profile
      if (section === 'Account') {
        const validAccountFields = ['firstName', 'lastName', 'email', 'headline', 'location'];
        if (validAccountFields.includes(key)) {
          await storage.updateUser(userId, { [key]: value });
        }
      } else {
        // Handle other settings sections
        await storage.updateUserSettings(userId, section, key, value);
      }
      
      res.json({ 
        success: true,
        message: "Settings updated successfully",
        section,
        key,
        value 
      });
    } catch (error) {
      console.error("Error updating settings:", error);
      res.status(500).json({ error: "Error updating settings" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
