import { db } from "./db";
import { users, posts, jobs, connections } from "@shared/schema";
import bcrypt from "bcrypt";

export async function seedDatabase() {
  try {
    console.log("Seeding database...");

    // Clear existing data
    await db.delete(connections);
    await db.delete(posts);
    await db.delete(jobs);
    await db.delete(users);

    // Seed users
    const hashedPassword = await bcrypt.hash("password123", 10);
    
    const sampleUsers = [
      {
        username: "johnsmith",
        email: "john@example.com",
        password: hashedPassword,
        firstName: "John",
        lastName: "Smith",
        headline: "Senior Software Engineer at TechCorp",
        location: "San Francisco, CA",
        profilePicture: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
        profileViews: 247,
        connections: 532
      },
      {
        username: "sarahconnor",
        email: "sarah@example.com", 
        password: hashedPassword,
        firstName: "Sarah",
        lastName: "Connor",
        headline: "VP of Engineering at InnovateTech",
        location: "New York, NY",
        profilePicture: "https://images.unsplash.com/photo-1494790108755-2616b332c98c?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
        profileViews: 892,
        connections: 1247
      },
      {
        username: "michaelchen",
        email: "michael@example.com",
        password: hashedPassword, 
        firstName: "Michael",
        lastName: "Chen",
        headline: "Product Manager at CloudScale",
        location: "Seattle, WA",
        profilePicture: "https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
        profileViews: 156,
        connections: 423
      },
      {
        username: "emilydavis",
        email: "emily@example.com",
        password: hashedPassword,
        firstName: "Emily",
        lastName: "Davis",
        headline: "UX Designer at CreativeStudio",
        location: "Austin, TX",
        profilePicture: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
        profileViews: 634,
        connections: 789
      },
      {
        username: "alexwang",
        email: "alex@example.com",
        password: hashedPassword,
        firstName: "Alex",
        lastName: "Wang",
        headline: "Data Scientist at AI Solutions",
        location: "Boston, MA",
        profilePicture: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
        profileViews: 321,
        connections: 567
      }
    ];

    const insertedUsers = await db.insert(users).values(sampleUsers).returning();
    console.log(`✓ Inserted ${insertedUsers.length} users`);

    // Seed posts
    const samplePosts = [
      {
        authorId: insertedUsers[1].id, // Sarah
        content: "Excited to share that our team just shipped a major feature that will help developers build better applications faster! 🚀\n\nThe journey wasn't easy, but seeing the positive impact on our users makes every late night worth it. Special thanks to my amazing team for their dedication and innovation.\n\n#TechInnovation #TeamWork #ProductLaunch",
        imageUrl: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        likes: 142,
        comments: 28,
        shares: 15
      },
      {
        authorId: insertedUsers[2].id, // Michael
        content: "Just finished an incredible workshop on \"Building User-Centric Products\" 📈\n\nKey takeaway: Always start with the problem, not the solution. Understanding your users' pain points is the foundation of any successful product.\n\nWhat's your go-to method for user research? Would love to hear your thoughts! 💭",
        likes: 89,
        comments: 12,
        shares: 7
      },
      {
        authorId: insertedUsers[3].id, // Emily
        content: "Design thinking isn't just about making things look pretty - it's about solving real problems for real people. 🎨\n\nToday I presented our new design system to the team. The goal? Create consistent, accessible experiences across all our products.\n\n#UXDesign #DesignSystems #UserExperience",
        likes: 67,
        comments: 15,
        shares: 4
      },
      {
        authorId: insertedUsers[4].id, // Alex
        content: "Machine learning models are only as good as the data they're trained on. 🤖\n\nSpent the morning cleaning and preprocessing a dataset for our new recommendation engine. It's not glamorous work, but it's essential for building reliable AI systems.\n\n#MachineLearning #DataScience #AI",
        likes: 94,
        comments: 18,
        shares: 11
      }
    ];

    const insertedPosts = await db.insert(posts).values(samplePosts).returning();
    console.log(`✓ Inserted ${insertedPosts.length} posts`);

    // Seed jobs
    const sampleJobs = [
      {
        title: "Senior Frontend Developer",
        company: "TechFlow Inc.",
        location: "San Francisco, CA",
        salary: "$120k-$160k",
        description: "Join our team building next-generation web applications with React, TypeScript, and modern tools. We're looking for someone passionate about creating exceptional user experiences.",
        recruiterName: "Jennifer Walsh",
        recruiterPicture: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50"
      },
      {
        title: "Product Manager", 
        company: "InnovateLabs",
        location: "Remote",
        salary: "$110k-$140k",
        description: "Lead product strategy for our growing SaaS platform. Work closely with engineering and design teams to deliver features that customers love.",
        recruiterName: "David Park",
        recruiterPicture: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50"
      },
      {
        title: "UX Designer",
        company: "DesignStudio Pro", 
        location: "New York, NY",
        salary: "$95k-$125k",
        description: "Create beautiful and intuitive user experiences for our mobile and web applications. Experience with Figma and user research required.",
        recruiterName: "Lisa Chen",
        recruiterPicture: "https://images.unsplash.com/photo-1507101105822-7472b28e22ac?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50"
      },
      {
        title: "Data Scientist",
        company: "AI Solutions Corp",
        location: "Boston, MA",
        salary: "$130k-$170k",
        description: "Build machine learning models to power our recommendation systems. Experience with Python, TensorFlow, and cloud platforms required.",
        recruiterName: "Mark Johnson",
        recruiterPicture: "https://images.unsplash.com/photo-1556157382-97eda2d62296?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50"
      },
      {
        title: "DevOps Engineer",
        company: "CloudTech Systems",
        location: "Austin, TX",
        salary: "$115k-$150k",
        description: "Design and maintain our cloud infrastructure. Work with Kubernetes, AWS, and CI/CD pipelines to ensure reliable deployments.",
        recruiterName: "Anna Rodriguez",
        recruiterPicture: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50"
      }
    ];

    const insertedJobs = await db.insert(jobs).values(sampleJobs).returning();
    console.log(`✓ Inserted ${insertedJobs.length} jobs`);

    // Seed some connections
    const sampleConnections = [
      {
        requesterId: insertedUsers[1].id, // Sarah requests John
        recipientId: insertedUsers[0].id,
        status: "pending"
      },
      {
        requesterId: insertedUsers[2].id, // Michael requests John
        recipientId: insertedUsers[0].id,
        status: "pending"
      },
      {
        requesterId: insertedUsers[0].id, // John requests Emily
        recipientId: insertedUsers[3].id,
        status: "accepted"
      },
      {
        requesterId: insertedUsers[1].id, // Sarah requests Alex
        recipientId: insertedUsers[4].id,
        status: "accepted"
      }
    ];

    const insertedConnections = await db.insert(connections).values(sampleConnections).returning();
    console.log(`✓ Inserted ${insertedConnections.length} connections`);

    console.log("✓ Database seeding completed successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
    throw error;
  }
}