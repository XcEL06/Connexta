import { users, posts, jobs, connections, postLikes, follows, userSettings, type User, type Post, type Job, type Connection, type PostLike, type Follow, type UserSettings, type InsertUser, type InsertPost, type InsertJob, type InsertConnection, type InsertFollow, type PostWithAuthor, type UserProfile } from "@shared/schema";
import { db } from "./db";
import { eq, and, or, desc } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  
  // Post methods
  getPosts(limit?: number, offset?: number): Promise<PostWithAuthor[]>;
  getPost(id: number): Promise<PostWithAuthor | undefined>;
  createPost(post: InsertPost): Promise<Post>;
  updatePost(id: number, updates: Partial<Post>): Promise<Post | undefined>;
  deletePost(id: number): Promise<boolean>;
  
  // Job methods
  getJobs(limit?: number): Promise<Job[]>;
  getJob(id: number): Promise<Job | undefined>;
  createJob(job: InsertJob): Promise<Job>;
  
  // Connection methods
  getConnections(userId: number): Promise<Connection[]>;
  createConnection(connection: InsertConnection): Promise<Connection>;
  updateConnectionStatus(id: number, status: string): Promise<Connection | undefined>;
  getPendingConnectionRequests(userId: number): Promise<(Connection & { requester: UserProfile })[]>;
  getSentConnectionRequests(userId: number): Promise<(Connection & { recipient: UserProfile })[]>;
  
  // Post interaction methods
  togglePostLike(postId: number, userId: number): Promise<boolean>;
  isPostLiked(postId: number, userId: number): Promise<boolean>;
  
  // Suggestion methods
  getSuggestedUsers(userId: number, limit?: number): Promise<UserProfile[]>;
  
  // Follow methods
  followUser(followerId: number, followingId: number): Promise<Follow>;
  unfollowUser(followerId: number, followingId: number): Promise<boolean>;
  isFollowing(followerId: number, followingId: number): Promise<boolean>;
  getFollowers(userId: number): Promise<UserProfile[]>;
  getFollowing(userId: number): Promise<UserProfile[]>;
  getFollowStats(userId: number): Promise<{ followers: number; following: number }>;
  
  // Settings methods
  getUserSettings(userId: number): Promise<any>;
  updateUserSettings(userId: number, section: string, key: string, value: any): Promise<any>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private posts: Map<number, Post>;
  private jobs: Map<number, Job>;
  private connections: Map<number, Connection>;
  private postLikes: Map<number, PostLike>;
  private currentUserId: number;
  private currentPostId: number;
  private currentJobId: number;
  private currentConnectionId: number;
  private currentPostLikeId: number;

  constructor() {
    this.users = new Map();
    this.posts = new Map();
    this.jobs = new Map();
    this.connections = new Map();
    this.postLikes = new Map();
    this.currentUserId = 1;
    this.currentPostId = 1;
    this.currentJobId = 1;
    this.currentConnectionId = 1;
    this.currentPostLikeId = 1;
    
    this.seedData();
  }

  private seedData() {
    // Seed sample users
    const sampleUsers: InsertUser[] = [
      {
        username: "johnsmith",
        email: "john@example.com",
        password: "password123",
        firstName: "John",
        lastName: "Smith",
        headline: "Senior Software Engineer at TechCorp",
        location: "San Francisco, CA",
        profilePicture: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100"
      },
      {
        username: "sarahconnor",
        email: "sarah@example.com", 
        password: "password123",
        firstName: "Sarah",
        lastName: "Connor",
        headline: "VP of Engineering at InnovateTech",
        location: "New York, NY",
        profilePicture: "https://images.unsplash.com/photo-1494790108755-2616b332c98c?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100"
      },
      {
        username: "michaelchen",
        email: "michael@example.com",
        password: "password123", 
        firstName: "Michael",
        lastName: "Chen",
        headline: "Product Manager at CloudScale",
        location: "Seattle, WA",
        profilePicture: "https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100"
      }
    ];

    sampleUsers.forEach(user => {
      const newUser: User = {
        ...user,
        id: this.currentUserId++,
        profileViews: Math.floor(Math.random() * 500) + 50,
        connections: Math.floor(Math.random() * 2000) + 100,
        createdAt: new Date(),
      };
      this.users.set(newUser.id, newUser);
    });

    // Seed sample posts
    const samplePosts: InsertPost[] = [
      {
        authorId: 2,
        content: "Excited to share that our team just shipped a major feature that will help developers build better applications faster! 🚀\n\nThe journey wasn't easy, but seeing the positive impact on our users makes every late night worth it. Special thanks to my amazing team for their dedication and innovation.\n\n#TechInnovation #TeamWork #ProductLaunch",
        imageUrl: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        likes: 142,
        comments: 28,
        shares: 15
      },
      {
        authorId: 3,
        content: "Just finished an incredible workshop on \"Building User-Centric Products\" 📈\n\nKey takeaway: Always start with the problem, not the solution. Understanding your users' pain points is the foundation of any successful product.\n\nWhat's your go-to method for user research? Would love to hear your thoughts! 💭",
        likes: 89,
        comments: 12,
        shares: 7
      }
    ];

    samplePosts.forEach(post => {
      const newPost: Post = {
        ...post,
        id: this.currentPostId++,
        createdAt: new Date(Date.now() - Math.random() * 86400000 * 7), // Random time within last week
      };
      this.posts.set(newPost.id, newPost);
    });

    // Seed sample jobs
    const sampleJobs: InsertJob[] = [
      {
        title: "Senior Frontend Developer",
        company: "TechFlow Inc.",
        location: "San Francisco, CA",
        salary: "$120k-$160k",
        description: "Join our team building next-generation web applications",
        recruiterName: "Jennifer Walsh",
        recruiterPicture: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50"
      },
      {
        title: "Product Manager", 
        company: "InnovateLabs",
        location: "Remote",
        salary: "$110k-$140k",
        description: "Lead product strategy for our growing platform",
        recruiterName: "David Park",
        recruiterPicture: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50"
      },
      {
        title: "UX Designer",
        company: "DesignStudio Pro", 
        location: "New York, NY",
        salary: "$95k-$125k",
        description: "Create beautiful and intuitive user experiences",
        recruiterName: "Lisa Chen",
        recruiterPicture: "https://images.unsplash.com/photo-1507101105822-7472b28e22ac?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50"
      }
    ];

    sampleJobs.forEach(job => {
      const newJob: Job = {
        ...job,
        id: this.currentJobId++,
        isActive: true,
        createdAt: new Date(),
      };
      this.jobs.set(newJob.id, newJob);
    });

    // Seed sample connection requests
    const sampleConnections: InsertConnection[] = [
      {
        requesterId: 2,
        recipientId: 1,
      },
      {
        requesterId: 3,
        recipientId: 1,
      }
    ];

    sampleConnections.forEach(connection => {
      const newConnection: Connection = {
        ...connection,
        id: this.currentConnectionId++,
        status: "pending",
        createdAt: new Date(),
      };
      this.connections.set(newConnection.id, newConnection);
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = {
      ...insertUser,
      id,
      profileViews: 0,
      connections: 0,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getPosts(limit = 10, offset = 0): Promise<PostWithAuthor[]> {
    const posts = Array.from(this.posts.values())
      .sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime())
      .slice(offset, offset + limit);

    return posts.map(post => {
      const author = this.users.get(post.authorId);
      return {
        ...post,
        author: {
          id: author!.id,
          firstName: author!.firstName,
          lastName: author!.lastName,
          headline: author!.headline,
          profilePicture: author!.profilePicture,
        }
      };
    });
  }

  async getPost(id: number): Promise<PostWithAuthor | undefined> {
    const post = this.posts.get(id);
    if (!post) return undefined;

    const author = this.users.get(post.authorId);
    if (!author) return undefined;

    return {
      ...post,
      author: {
        id: author.id,
        firstName: author.firstName,
        lastName: author.lastName,
        headline: author.headline,
        profilePicture: author.profilePicture,
      }
    };
  }

  async createPost(insertPost: InsertPost): Promise<Post> {
    const id = this.currentPostId++;
    const post: Post = {
      ...insertPost,
      id,
      likes: 0,
      comments: 0,
      shares: 0,
      createdAt: new Date(),
    };
    this.posts.set(id, post);
    return post;
  }

  async updatePost(id: number, updates: Partial<Post>): Promise<Post | undefined> {
    const post = this.posts.get(id);
    if (!post) return undefined;
    
    const updatedPost = { ...post, ...updates };
    this.posts.set(id, updatedPost);
    return updatedPost;
  }

  async deletePost(id: number): Promise<boolean> {
    return this.posts.delete(id);
  }

  async getJobs(limit = 10): Promise<Job[]> {
    return Array.from(this.jobs.values())
      .filter(job => job.isActive)
      .slice(0, limit);
  }

  async getJob(id: number): Promise<Job | undefined> {
    return this.jobs.get(id);
  }

  async createJob(insertJob: InsertJob): Promise<Job> {
    const id = this.currentJobId++;
    const job: Job = {
      ...insertJob,
      id,
      isActive: true,
      createdAt: new Date(),
    };
    this.jobs.set(id, job);
    return job;
  }

  async getConnections(userId: number): Promise<Connection[]> {
    return Array.from(this.connections.values())
      .filter(conn => 
        (conn.requesterId === userId || conn.recipientId === userId) && 
        conn.status === "accepted"
      );
  }

  async getPendingConnectionRequests(userId: number): Promise<(Connection & { requester: UserProfile })[]> {
    return Array.from(this.connections.values())
      .filter(conn => conn.recipientId === userId && conn.status === "pending")
      .map(conn => {
        const requester = this.users.get(conn.requesterId);
        return {
          ...conn,
          requester: {
            id: requester!.id,
            firstName: requester!.firstName,
            lastName: requester!.lastName,
            headline: requester!.headline,
            location: requester!.location,
            profilePicture: requester!.profilePicture,
            coverPicture: requester!.coverPicture,
            profileViews: requester!.profileViews,
            connections: requester!.connections,
          }
        };
      });
  }

  async getSentConnectionRequests(userId: number): Promise<(Connection & { recipient: UserProfile })[]> {
    return Array.from(this.connections.values())
      .filter(conn => conn.requesterId === userId && conn.status === "pending")
      .map(conn => {
        const recipient = this.users.get(conn.recipientId);
        return {
          ...conn,
          recipient: {
            id: recipient!.id,
            firstName: recipient!.firstName,
            lastName: recipient!.lastName,
            headline: recipient!.headline,
            location: recipient!.location,
            profilePicture: recipient!.profilePicture,
            coverPicture: recipient!.coverPicture,
            profileViews: recipient!.profileViews,
            connections: recipient!.connections,
          }
        };
      });
  }

  async createConnection(insertConnection: InsertConnection): Promise<Connection> {
    // Check if connection request already exists
    const existingConnection = Array.from(this.connections.values())
      .find(conn => 
        (conn.requesterId === insertConnection.requesterId && conn.recipientId === insertConnection.recipientId) ||
        (conn.requesterId === insertConnection.recipientId && conn.recipientId === insertConnection.requesterId)
      );
    
    if (existingConnection) {
      throw new Error("Connection request already exists");
    }

    const id = this.currentConnectionId++;
    const connection: Connection = {
      ...insertConnection,
      id,
      status: "pending",
      createdAt: new Date(),
    };
    this.connections.set(id, connection);
    return connection;
  }

  async updateConnectionStatus(id: number, status: string): Promise<Connection | undefined> {
    const connection = this.connections.get(id);
    if (!connection) return undefined;
    
    const updatedConnection = { ...connection, status };
    this.connections.set(id, updatedConnection);
    return updatedConnection;
  }

  async togglePostLike(postId: number, userId: number): Promise<boolean> {
    const existingLike = Array.from(this.postLikes.values())
      .find(like => like.postId === postId && like.userId === userId);

    if (existingLike) {
      this.postLikes.delete(existingLike.id);
      const post = this.posts.get(postId);
      if (post) {
        post.likes = Math.max(0, post.likes! - 1);
        this.posts.set(postId, post);
      }
      return false;
    } else {
      const id = this.currentPostLikeId++;
      const like: PostLike = {
        id,
        postId,
        userId,
        createdAt: new Date(),
      };
      this.postLikes.set(id, like);
      const post = this.posts.get(postId);
      if (post) {
        post.likes = (post.likes || 0) + 1;
        this.posts.set(postId, post);
      }
      return true;
    }
  }

  async isPostLiked(postId: number, userId: number): Promise<boolean> {
    return Array.from(this.postLikes.values())
      .some(like => like.postId === postId && like.userId === userId);
  }

  async getSuggestedUsers(userId: number, limit = 5): Promise<UserProfile[]> {
    const connectedUserIds = new Set(
      Array.from(this.connections.values())
        .filter(conn => 
          (conn.requesterId === userId || conn.recipientId === userId) && 
          conn.status === 'accepted'
        )
        .map(conn => conn.requesterId === userId ? conn.recipientId : conn.requesterId)
    );

    const pendingRequestUserIds = new Set(
      Array.from(this.connections.values())
        .filter(conn => 
          (conn.requesterId === userId || conn.recipientId === userId) && 
          conn.status === 'pending'
        )
        .map(conn => conn.requesterId === userId ? conn.recipientId : conn.requesterId)
    );

    return Array.from(this.users.values())
      .filter(user => 
        user.id !== userId && 
        !connectedUserIds.has(user.id) && 
        !pendingRequestUserIds.has(user.id)
      )
      .slice(0, limit)
      .map(user => ({
        id: user.id,
        firstName: user.firstName,
        lastName: user.lastName,
        headline: user.headline,
        location: user.location,
        profilePicture: user.profilePicture,
        coverPicture: user.coverPicture,
        profileViews: user.profileViews,
        connections: user.connections,
      }));
  }
}

// Database Storage Implementation
export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async getPosts(limit = 10, offset = 0): Promise<PostWithAuthor[]> {
    const postsWithAuthors = await db
      .select({
        id: posts.id,
        authorId: posts.authorId,
        content: posts.content,
        imageUrl: posts.imageUrl,
        likes: posts.likes,
        comments: posts.comments,
        shares: posts.shares,
        createdAt: posts.createdAt,
        author: {
          id: users.id,
          firstName: users.firstName,
          lastName: users.lastName,
          headline: users.headline,
          profilePicture: users.profilePicture,
        }
      })
      .from(posts)
      .innerJoin(users, eq(posts.authorId, users.id))
      .orderBy(desc(posts.createdAt))
      .limit(limit)
      .offset(offset);

    return postsWithAuthors;
  }

  async getPost(id: number): Promise<PostWithAuthor | undefined> {
    const [postWithAuthor] = await db
      .select({
        id: posts.id,
        authorId: posts.authorId,
        content: posts.content,
        imageUrl: posts.imageUrl,
        likes: posts.likes,
        comments: posts.comments,
        shares: posts.shares,
        createdAt: posts.createdAt,
        author: {
          id: users.id,
          firstName: users.firstName,
          lastName: users.lastName,
          headline: users.headline,
          profilePicture: users.profilePicture,
        }
      })
      .from(posts)
      .innerJoin(users, eq(posts.authorId, users.id))
      .where(eq(posts.id, id));

    return postWithAuthor || undefined;
  }

  async createPost(insertPost: InsertPost): Promise<Post> {
    const [post] = await db
      .insert(posts)
      .values(insertPost)
      .returning();
    return post;
  }

  async updatePost(id: number, updates: Partial<Post>): Promise<Post | undefined> {
    const [post] = await db
      .update(posts)
      .set(updates)
      .where(eq(posts.id, id))
      .returning();
    return post || undefined;
  }

  async deletePost(id: number): Promise<boolean> {
    const result = await db
      .delete(posts)
      .where(eq(posts.id, id));
    return result.rowCount > 0;
  }

  async getJobs(limit = 10): Promise<Job[]> {
    return await db
      .select()
      .from(jobs)
      .where(eq(jobs.isActive, true))
      .limit(limit);
  }

  async getJob(id: number): Promise<Job | undefined> {
    const [job] = await db.select().from(jobs).where(eq(jobs.id, id));
    return job || undefined;
  }

  async createJob(insertJob: InsertJob): Promise<Job> {
    const [job] = await db
      .insert(jobs)
      .values(insertJob)
      .returning();
    return job;
  }

  async getConnections(userId: number): Promise<Connection[]> {
    return await db
      .select()
      .from(connections)
      .where(
        and(
          or(
            eq(connections.requesterId, userId),
            eq(connections.recipientId, userId)
          ),
          eq(connections.status, "accepted")
        )
      );
  }

  async getPendingConnectionRequests(userId: number): Promise<(Connection & { requester: UserProfile })[]> {
    const requests = await db
      .select({
        id: connections.id,
        requesterId: connections.requesterId,
        recipientId: connections.recipientId,
        status: connections.status,
        createdAt: connections.createdAt,
        requester: {
          id: users.id,
          firstName: users.firstName,
          lastName: users.lastName,
          headline: users.headline,
          location: users.location,
          profilePicture: users.profilePicture,
          coverPicture: users.coverPicture,
          profileViews: users.profileViews,
          connections: users.connections,
        }
      })
      .from(connections)
      .innerJoin(users, eq(connections.requesterId, users.id))
      .where(
        and(
          eq(connections.recipientId, userId),
          eq(connections.status, "pending")
        )
      );

    return requests;
  }

  async getSentConnectionRequests(userId: number): Promise<(Connection & { recipient: UserProfile })[]> {
    const requests = await db
      .select({
        id: connections.id,
        requesterId: connections.requesterId,
        recipientId: connections.recipientId,
        status: connections.status,
        createdAt: connections.createdAt,
        recipient: {
          id: users.id,
          firstName: users.firstName,
          lastName: users.lastName,
          headline: users.headline,
          location: users.location,
          profilePicture: users.profilePicture,
          coverPicture: users.coverPicture,
          profileViews: users.profileViews,
          connections: users.connections,
        }
      })
      .from(connections)
      .innerJoin(users, eq(connections.recipientId, users.id))
      .where(
        and(
          eq(connections.requesterId, userId),
          eq(connections.status, "pending")
        )
      );

    return requests;
  }

  async createConnection(insertConnection: InsertConnection): Promise<Connection> {
    // Check if connection request already exists
    const [existingConnection] = await db
      .select()
      .from(connections)
      .where(
        or(
          and(
            eq(connections.requesterId, insertConnection.requesterId),
            eq(connections.recipientId, insertConnection.recipientId)
          ),
          and(
            eq(connections.requesterId, insertConnection.recipientId),
            eq(connections.recipientId, insertConnection.requesterId)
          )
        )
      );

    if (existingConnection) {
      throw new Error("Connection request already exists");
    }

    const [connection] = await db
      .insert(connections)
      .values(insertConnection)
      .returning();
    return connection;
  }

  async updateConnectionStatus(id: number, status: string): Promise<Connection | undefined> {
    const [connection] = await db
      .update(connections)
      .set({ status })
      .where(eq(connections.id, id))
      .returning();
    return connection || undefined;
  }

  async togglePostLike(postId: number, userId: number): Promise<boolean> {
    const [existingLike] = await db
      .select()
      .from(postLikes)
      .where(
        and(
          eq(postLikes.postId, postId),
          eq(postLikes.userId, userId)
        )
      );

    if (existingLike) {
      // Remove like
      await db
        .delete(postLikes)
        .where(eq(postLikes.id, existingLike.id));
      
      // Decrease like count
      const [currentPost] = await db.select().from(posts).where(eq(posts.id, postId));
      if (currentPost) {
        await db
          .update(posts)
          .set({ likes: Math.max(0, (currentPost.likes || 0) - 1) })
          .where(eq(posts.id, postId));
      }
      
      return false;
    } else {
      // Add like
      await db
        .insert(postLikes)
        .values({ postId, userId });
      
      // Increase like count
      const [currentPost] = await db.select().from(posts).where(eq(posts.id, postId));
      if (currentPost) {
        await db
          .update(posts)
          .set({ likes: (currentPost.likes || 0) + 1 })
          .where(eq(posts.id, postId));
      }
      
      return true;
    }
  }

  async isPostLiked(postId: number, userId: number): Promise<boolean> {
    const [like] = await db
      .select()
      .from(postLikes)
      .where(
        and(
          eq(postLikes.postId, postId),
          eq(postLikes.userId, userId)
        )
      );
    return !!like;
  }

  async getSuggestedUsers(userId: number, limit = 5): Promise<UserProfile[]> {
    // Get all connected and pending connection user IDs
    const userConnections = await db
      .select({
        connectedId: connections.requesterId,
      })
      .from(connections)
      .where(
        or(
          eq(connections.recipientId, userId),
          eq(connections.requesterId, userId)
        )
      );

    const connectedUserIds = new Set([
      ...userConnections.map(c => c.connectedId),
      userId // Exclude self
    ]);

    // Get recipient IDs as well
    const recipientConnections = await db
      .select({
        connectedId: connections.recipientId,
      })
      .from(connections)
      .where(
        or(
          eq(connections.recipientId, userId),
          eq(connections.requesterId, userId)
        )
      );

    recipientConnections.forEach(c => connectedUserIds.add(c.connectedId));

    const suggestedUsers = await db
      .select({
        id: users.id,
        firstName: users.firstName,
        lastName: users.lastName,
        headline: users.headline,
        location: users.location,
        profilePicture: users.profilePicture,
        coverPicture: users.coverPicture,
        profileViews: users.profileViews,
        connections: users.connections,
      })
      .from(users)
      .limit(limit + connectedUserIds.size); // Get extra to filter out

    return suggestedUsers
      .filter(user => !connectedUserIds.has(user.id))
      .slice(0, limit);
  }

  async followUser(followerId: number, followingId: number): Promise<Follow> {
    // Check if already following
    const [existingFollow] = await db
      .select()
      .from(follows)
      .where(
        and(
          eq(follows.followerId, followerId),
          eq(follows.followingId, followingId)
        )
      );

    if (existingFollow) {
      throw new Error("Already following this user");
    }

    if (followerId === followingId) {
      throw new Error("Cannot follow yourself");
    }

    const [follow] = await db
      .insert(follows)
      .values({ followerId, followingId })
      .returning();
    
    return follow;
  }

  async unfollowUser(followerId: number, followingId: number): Promise<boolean> {
    const result = await db
      .delete(follows)
      .where(
        and(
          eq(follows.followerId, followerId),
          eq(follows.followingId, followingId)
        )
      );
    
    return result.rowCount > 0;
  }

  async isFollowing(followerId: number, followingId: number): Promise<boolean> {
    const [follow] = await db
      .select()
      .from(follows)
      .where(
        and(
          eq(follows.followerId, followerId),
          eq(follows.followingId, followingId)
        )
      );
    
    return !!follow;
  }

  async getFollowers(userId: number): Promise<UserProfile[]> {
    const followers = await db
      .select({
        id: users.id,
        firstName: users.firstName,
        lastName: users.lastName,
        headline: users.headline,
        location: users.location,
        profilePicture: users.profilePicture,
        coverPicture: users.coverPicture,
        profileViews: users.profileViews,
        connections: users.connections,
      })
      .from(follows)
      .innerJoin(users, eq(follows.followerId, users.id))
      .where(eq(follows.followingId, userId));

    return followers;
  }

  async getFollowing(userId: number): Promise<UserProfile[]> {
    const following = await db
      .select({
        id: users.id,
        firstName: users.firstName,
        lastName: users.lastName,
        headline: users.headline,
        location: users.location,
        profilePicture: users.profilePicture,
        coverPicture: users.coverPicture,
        profileViews: users.profileViews,
        connections: users.connections,
      })
      .from(follows)
      .innerJoin(users, eq(follows.followingId, users.id))
      .where(eq(follows.followerId, userId));

    return following;
  }

  async getFollowStats(userId: number): Promise<{ followers: number; following: number }> {
    const [followersCount] = await db
      .select({ count: follows.id })
      .from(follows)
      .where(eq(follows.followingId, userId));

    const [followingCount] = await db
      .select({ count: follows.id })
      .from(follows)
      .where(eq(follows.followerId, userId));

    return {
      followers: followersCount?.count || 0,
      following: followingCount?.count || 0,
    };
  }
}

export const storage = new DatabaseStorage();
